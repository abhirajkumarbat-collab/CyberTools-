package com.example.ai

import android.util.Log
import com.example.BuildConfig
import com.example.model.ChatMessage
import com.example.model.CyberResource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class CyberBotManager {
    private val tag = "CyberBotManager"
    private val modelName = "gemini-3.5-flash"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val systemInstruction = """
        You are CYBERBOT PRO, the elite embedded cybersecurity learning assistant inside "CyberHub: Cyber Resource & Learning Hub Pro".
        
        YOUR MISSION:
        Educate, guide, and empower users in ethical hacking, networking, Linux administration, packet analysis, and defensive cybersecurity practices.
        
        BEHAVIORAL MANDATES:
        1. Always maintain a lawful, ethical, defensive, and authorized testing perspective (labs, CTFs, local virtualized environments).
        2. Provide exact, structured command-line examples, bash commands, and step-by-step methodologies.
        3. Explain 'how, why, and when' to use tools and security concepts.
        4. When relevant app resources exist, reference them clearly so the user can locate them in the app.
        5. Keep your tone professional, crisp, encouraging, and knowledgeable.
    """.trimIndent()

    /**
     * Resolves the Gemini API key from BuildConfig (injected via .env from AI Studio secrets)
     * or directly from environment variables.
     */
    fun getApiKey(): String {
        val buildConfigKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }
        val envKey = try {
            System.getenv("GEMINI_API_KEY") ?: ""
        } catch (e: Throwable) {
            ""
        }
        return sequenceOf(buildConfigKey, envKey)
            .firstOrNull { it.isNotBlank() && it != "MY_GEMINI_API_KEY" } ?: ""
    }

    suspend fun generateResponse(
        userQuery: String,
        currentScreen: String,
        availableResources: List<CyberResource>,
        chatHistory: List<ChatMessage> = emptyList()
    ): ChatMessage = withContext(Dispatchers.IO) {
        val resourceContext = if (availableResources.isNotEmpty()) {
            "Available Resources in App Catalog:\n" + availableResources.take(6).joinToString("\n") {
                "- [${it.category.uppercase()}] ${it.title}: ${it.description.take(80)}"
            }
        } else {
            "No resources currently published in the catalog yet."
        }

        val fullSystemPrompt = """
            $systemInstruction
            
            Current User Screen Context: $currentScreen
            $resourceContext
        """.trimIndent()

        // 1. Try Gemini API via REST if API key is configured
        val apiKey = getApiKey()

        if (apiKey.isNotBlank()) {
            try {
                val responseText = callGeminiRestApi(apiKey, fullSystemPrompt, userQuery, chatHistory)
                if (!responseText.isNullOrBlank()) {
                    return@withContext ChatMessage(
                        role = "assistant",
                        content = responseText
                    )
                }
            } catch (e: Exception) {
                Log.w(tag, "Gemini REST call failed: ${e.message}")
            }
        } else {
            Log.d(tag, "No GEMINI_API_KEY found in BuildConfig or environment variables. Using smart offline engine.")
        }

        // 2. Intelligent Offline/Fallback Technical Mentor Engine
        val fallbackText = generateIntelligentResponse(userQuery, availableResources)
        ChatMessage(
            role = "assistant",
            content = fallbackText
        )
    }

    private fun callGeminiRestApi(
        apiKey: String,
        systemPrompt: String,
        userQuery: String,
        chatHistory: List<ChatMessage>
    ): String? {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"

        val jsonPayload = JSONObject().apply {
            // System instruction
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            })

            // Multi-turn contents: Start from first user turn, alternating user and model
            val contentsArray = JSONArray()
            val historyForApi = chatHistory.dropWhile { it.role != "user" }
            var lastRole = ""

            for (msg in historyForApi.takeLast(10)) {
                val apiRole = if (msg.role == "user") "user" else "model"
                if (apiRole != lastRole) {
                    val partObj = JSONObject().put("text", msg.content)
                    val contentObj = JSONObject().apply {
                        put("role", apiRole)
                        put("parts", JSONArray().put(partObj))
                    }
                    contentsArray.put(contentObj)
                    lastRole = apiRole
                }
            }

            // Ensure the user's latest query is present at the end
            if (lastRole != "user") {
                val currentMsgObj = JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", userQuery)))
                }
                contentsArray.put(currentMsgObj)
            }

            put("contents", contentsArray)

            // Generation config
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("topK", 40)
                put("topP", 0.95)
                put("maxOutputTokens", 2048)
            })
        }

        val body = jsonPayload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()

        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val errBody = response.body?.string() ?: ""
                Log.w(tag, "Gemini API error code ${response.code}: $errBody")
                return null
            }

            val bodyString = response.body?.string() ?: return null
            val root = JSONObject(bodyString)
            val candidates = root.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    return parts.getJSONObject(0).optString("text")
                }
            }
        }
        return null
    }

    private fun generateIntelligentResponse(query: String, resources: List<CyberResource>): String {
        val q = query.lowercase().trim()
        val matchingResources = resources.filter {
            it.title.contains(q, ignoreCase = true) || it.description.contains(q, ignoreCase = true) || it.tags.contains(q, ignoreCase = true)
        }

        val resourceSuggestion = if (matchingResources.isNotEmpty()) {
            "\n\n📂 **Matching resources in your CyberHub catalog:**\n" +
                    matchingResources.take(3).joinToString("\n") { "• **${it.title}** (${it.category})" }
        } else ""

        return when {
            q.contains("packet") || q.contains("wireshark") -> {
                "🔍 **Packet Inspection & Network Analysis**\n\n" +
                        "Packet inspection allows security engineers to analyze packets transmitted across a network interface.\n\n" +
                        "**Key Steps for Authorized Lab Testing:**\n" +
                        "1. **Capture Interface:** Select your local loopback or test adapter (e.g., `eth0`, `wlan0`).\n" +
                        "2. **Display Filters:** Use Wireshark filters such as `http.request.method == \"GET\"` or `tcp.flags.syn == 1` to isolate handshakes.\n" +
                        "3. **Decryption (TLS):** Inspect TLS sessions in your testing environment using the `SSLKEYLOGFILE` environment variable.\n\n" +
                        "🛡️ *Defensive Rule: Never inspect network traffic on infrastructure you do not own or have written authorization to audit.*$resourceSuggestion"
            }
            q.contains("nmap") || q.contains("port") || q.contains("scan") -> {
                "⚡ **Network Mapping & Port Auditing with Nmap**\n\n" +
                        "Nmap (Network Mapper) identifies open ports and running service banners to verify firewall posture.\n\n" +
                        "**Standard Educational Commands:**\n" +
                        "• `nmap -sV -sC -p- 192.168.1.100` — Full service version and default scripts scan.\n" +
                        "• `nmap -sn 192.168.1.0/24` — Ping sweep to discover live hosts on your local lab subnet.\n" +
                        "• `nmap -F scanme.nmap.org` — Fast scan against the official authorized test host.\n\n" +
                        "💡 *Best Practice: Always verify authorization and specify exact port ranges to avoid unnecessary network saturation.*$resourceSuggestion"
            }
            q.contains("termux") || q.contains("linux") || q.contains("terminal") -> {
                "🐧 **Linux & Terminal Lab Best Practices**\n\n" +
                        "Linux terminal environments provide the foundational CLI tools for ethical security testing and automation.\n\n" +
                        "**Core Setup Steps:**\n" +
                        "1. `pkg update && pkg upgrade` — Keep package repositories updated.\n" +
                        "2. `pkg install git python curl ncurses-utils` — Install core toolchains.\n" +
                        "3. Maintain non-root sandboxed testing environments whenever experimenting with new scripts.$resourceSuggestion"
            }
            q.contains("hello") || q.contains("hi") || q.contains("hey") -> {
                "🛡️ **Welcome to CyberBot Pro!**\n\n" +
                        "I am your dedicated cybersecurity mentor and technical navigator for **CyberHub**.\n\n" +
                        "You can ask me about:\n" +
                        "• Network packet analysis & Wireshark filters\n" +
                        "• Defensive security methodologies and lab setup\n" +
                        "• How to use tools and verify software integrity (SHA-256)\n" +
                        "• Recommendations from your CyberHub resource catalog$resourceSuggestion"
            }
            else -> {
                "🛡️ **CyberBot Pro Analysis**\n\n" +
                        "Regarding \"$query\":\n\n" +
                        "In cybersecurity and defensive system administration, it is critical to adhere to structured methodologies:\n" +
                        "1. **Reconnaissance & Mapping:** Understand network topology and endpoints.\n" +
                        "2. **Threat Modeling:** Evaluate attack surfaces and security controls.\n" +
                        "3. **Defensive Hardening:** Apply least-privilege configurations, enforce encryption (TLS 1.3), and enable multi-factor authentication (2FA).\n\n" +
                        "Feel free to ask for specific commands, configuration guides, or tool setup steps!$resourceSuggestion"
            }
        }
    }
}
