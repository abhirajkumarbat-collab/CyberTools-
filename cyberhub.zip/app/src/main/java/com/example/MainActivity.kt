package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.ui.components.AddResourceDialog
import com.example.ui.components.CyberTopBar
import com.example.ui.components.ResourceDetailsBottomSheet
import com.example.ui.components.UserAuthBottomSheet
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CatalogScreen
import com.example.ui.screens.CyberBotScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SavedScreen
import com.example.ui.theme.CyberBg1
import com.example.ui.theme.CyberBg2
import com.example.ui.theme.CyberHubTheme
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.viewmodel.CyberHubViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: CyberHubViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CyberHubTheme {
                CyberHubApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun CyberHubApp(viewModel: CyberHubViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    if (uiState.showAuthScreen) {
        AuthScreen(
            viewModel = viewModel,
            uiState = uiState,
            onContinueToApp = { viewModel.dismissAuthScreen() }
        )
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                CyberTopBar(
                    title = when (uiState.currentNavTab) {
                        0 -> "CyberHub"
                        1 -> "Resource Catalog"
                        2 -> "CyberBot Pro"
                        3 -> "Saved Resources"
                        else -> "Admin Center"
                    },
                    subtitle = when (uiState.currentNavTab) {
                        0 -> "Server-Driven Hub"
                        1 -> uiState.selectedCategory.displayName
                        2 -> "AI Security Mentor"
                        3 -> "Offline Bookmarks"
                        else -> "Live Management"
                    },
                    syncStatus = uiState.syncStatus,
                    isAdmin = uiState.isAdmin,
                    onAccountClick = { viewModel.openAuthDialog() },
                    onAddClick = { viewModel.openAddDialog() }
                )
            },
        bottomBar = {
            NavigationBar(
                containerColor = CyberBg1,
                contentColor = CyberTextPrimary,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = uiState.currentNavTab == 0,
                    onClick = { viewModel.selectNavTab(0) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberPrimary,
                        selectedTextColor = CyberPrimary,
                        unselectedIconColor = CyberTextSecondary,
                        unselectedTextColor = CyberTextSecondary,
                        indicatorColor = CyberBg2
                    ),
                    modifier = Modifier.testTag("nav_home")
                )
                NavigationBarItem(
                    selected = uiState.currentNavTab == 1,
                    onClick = { viewModel.selectNavTab(1) },
                    icon = { Icon(Icons.Default.Explore, contentDescription = "Explore") },
                    label = { Text("Catalog") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberPrimary,
                        selectedTextColor = CyberPrimary,
                        unselectedIconColor = CyberTextSecondary,
                        unselectedTextColor = CyberTextSecondary,
                        indicatorColor = CyberBg2
                    ),
                    modifier = Modifier.testTag("nav_catalog")
                )
                NavigationBarItem(
                    selected = uiState.currentNavTab == 2,
                    onClick = { viewModel.selectNavTab(2) },
                    icon = { Icon(Icons.Default.SmartToy, contentDescription = "CyberBot") },
                    label = { Text("CyberBot") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberPrimary,
                        selectedTextColor = CyberPrimary,
                        unselectedIconColor = CyberTextSecondary,
                        unselectedTextColor = CyberTextSecondary,
                        indicatorColor = CyberBg2
                    ),
                    modifier = Modifier.testTag("nav_cyberbot")
                )
                NavigationBarItem(
                    selected = uiState.currentNavTab == 3,
                    onClick = { viewModel.selectNavTab(3) },
                    icon = { Icon(Icons.Default.Bookmark, contentDescription = "Saved") },
                    label = { Text("Saved") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberPrimary,
                        selectedTextColor = CyberPrimary,
                        unselectedIconColor = CyberTextSecondary,
                        unselectedTextColor = CyberTextSecondary,
                        indicatorColor = CyberBg2
                    ),
                    modifier = Modifier.testTag("nav_saved")
                )
                if (uiState.isAdmin) {
                    NavigationBarItem(
                        selected = uiState.currentNavTab == 4,
                        onClick = { viewModel.selectNavTab(4) },
                        icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin") },
                        label = { Text("Admin") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberPrimary,
                            selectedTextColor = CyberPrimary,
                            unselectedIconColor = CyberTextSecondary,
                            unselectedTextColor = CyberTextSecondary,
                            indicatorColor = CyberBg2
                        ),
                        modifier = Modifier.testTag("nav_admin")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.currentNavTab) {
                0 -> HomeScreen(
                    uiState = uiState,
                    onSearchChange = { viewModel.onSearchQueryChange(it) },
                    onCategorySelect = { viewModel.onCategorySelect(it) },
                    onResourceClick = { viewModel.openResourceDetails(it) },
                    onFavoriteToggle = { viewModel.toggleFavorite(it) },
                    onAddClick = { viewModel.openAddDialog() },
                    onNavigateToTab = { viewModel.selectNavTab(it) }
                )
                1 -> CatalogScreen(
                    uiState = uiState,
                    onSearchChange = { viewModel.onSearchQueryChange(it) },
                    onCategorySelect = { viewModel.onCategorySelect(it) },
                    onResourceClick = { viewModel.openResourceDetails(it) },
                    onFavoriteToggle = { viewModel.toggleFavorite(it) },
                    onAddClick = { viewModel.openAddDialog() }
                )
                2 -> CyberBotScreen(
                    uiState = uiState,
                    onSendMessage = { viewModel.sendChatMessage(it) }
                )
                3 -> SavedScreen(
                    uiState = uiState,
                    onResourceClick = { viewModel.openResourceDetails(it) },
                    onFavoriteToggle = { viewModel.toggleFavorite(it) },
                    onExploreClick = { viewModel.selectNavTab(1) }
                )
                4 -> {
                    if (uiState.isAdmin) {
                        AdminScreen(
                            uiState = uiState,
                            viewModel = viewModel,
                            onOpenAddDialog = { viewModel.openAddDialog() },
                            onBulkImport = { raw, cat -> viewModel.bulkImportLinks(raw, cat) },
                            onClearLocalData = { viewModel.clearLocalData() }
                        )
                    } else {
                        HomeScreen(
                            uiState = uiState,
                            onSearchChange = { viewModel.onSearchQueryChange(it) },
                            onCategorySelect = { viewModel.onCategorySelect(it) },
                            onResourceClick = { viewModel.openResourceDetails(it) },
                            onFavoriteToggle = { viewModel.toggleFavorite(it) },
                            onAddClick = { viewModel.openAddDialog() },
                            onNavigateToTab = { viewModel.selectNavTab(it) }
                        )
                    }
                }
            }

            // Resource Details Sheet
            uiState.selectedResourceForDetails?.let { item ->
                ResourceDetailsBottomSheet(
                    resource = item,
                    onDismiss = { viewModel.closeResourceDetails() },
                    onFavoriteToggle = { viewModel.toggleFavorite(item) },
                    onDelete = { viewModel.deleteResource(it) }
                )
            }

            // Add Real Resource Dialog
            if (uiState.isAddDialogOpen) {
                AddResourceDialog(
                    initialCategory = uiState.selectedCategory,
                    onDismiss = { viewModel.closeAddDialog() },
                    onConfirm = { title, desc, cat, url, ver, lvl ->
                        viewModel.addResource(title, desc, cat, url, ver, lvl)
                    }
                )
            }

            // User & Admin Auth Sheet
            if (uiState.isAuthDialogOpen) {
                UserAuthBottomSheet(
                    isAdmin = uiState.isAdmin,
                    currentUserEmail = uiState.currentUserEmail,
                    currentUserId = uiState.currentUserId,
                    isCheckingRole = uiState.isCheckingAdminRole,
                    onDismiss = { viewModel.closeAuthDialog() },
                    onSignIn = { email, pass, onResult -> viewModel.signInWithEmail(email, pass, onResult) },
                    onSignUp = { email, pass, onResult -> viewModel.signUpWithEmail(email, pass, onResult) },
                    onGuestSignIn = { onResult -> viewModel.signInAnonymously(onResult) },
                    onSignOut = { 
                        viewModel.signOut()
                        viewModel.closeAuthDialog()
                    },
                    onRefreshRole = { viewModel.checkUserRole() },
                    onOpenAuthScreen = { viewModel.openAuthScreen() }
                )
            }
        }
    }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
