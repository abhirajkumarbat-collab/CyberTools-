package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.model.CyberResource
import kotlinx.coroutines.flow.Flow

@Dao
interface CyberResourceDao {
    @Query("SELECT * FROM resources ORDER BY timestamp DESC")
    fun getAllResources(): Flow<List<CyberResource>>

    @Query("SELECT * FROM resources WHERE category = :category ORDER BY timestamp DESC")
    fun getResourcesByCategory(category: String): Flow<List<CyberResource>>

    @Query("SELECT * FROM resources WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavoriteResources(): Flow<List<CyberResource>>

    @Query("SELECT * FROM resources WHERE id = :id LIMIT 1")
    fun getResourceById(id: String): Flow<CyberResource?>

    @Query("SELECT * FROM resources WHERE title LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchResources(query: String): Flow<List<CyberResource>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResources(resources: List<CyberResource>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResource(resource: CyberResource)

    @Update
    suspend fun updateResource(resource: CyberResource)

    @Query("UPDATE resources SET isFavorite = :isFav WHERE id = :id")
    suspend fun setFavorite(id: String, isFav: Boolean)

    @Query("DELETE FROM resources WHERE id = :id")
    suspend fun deleteResourceById(id: String)

    @Query("DELETE FROM resources")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM resources")
    suspend fun getCount(): Int
}
