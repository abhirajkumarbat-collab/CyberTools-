package com.example.data

import android.util.Log
import com.example.model.CyberResource
import com.example.model.ResourceCategory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import java.util.UUID

class CyberHubRepository(
    private val dao: CyberResourceDao,
    private val firebaseManager: FirebaseManager = FirebaseManager(),
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val tag = "CyberHubRepository"

    init {
        // Start real-time Firestore listener to keep local Room database in sync
        startRealtimeSync()
    }

    private fun startRealtimeSync() {
        scope.launch {
            try {
                firebaseManager.getResourcesRealtime().collect { remoteItems ->
                    if (remoteItems.isNotEmpty()) {
                        dao.insertResources(remoteItems)
                        Log.d(tag, "Synced ${remoteItems.size} items from Firebase into Room DB")
                    }
                }
            } catch (e: Exception) {
                Log.w(tag, "Firestore sync skipped or offline: ${e.message}")
            }
        }
    }

    fun getAllResources(): Flow<List<CyberResource>> = dao.getAllResources().flowOn(Dispatchers.IO)

    fun getResourcesByCategory(category: ResourceCategory): Flow<List<CyberResource>> {
        return if (category == ResourceCategory.ALL) {
            dao.getAllResources()
        } else {
            dao.getResourcesByCategory(category.id)
        }.flowOn(Dispatchers.IO)
    }

    fun getFavorites(): Flow<List<CyberResource>> = dao.getFavoriteResources().flowOn(Dispatchers.IO)

    fun search(query: String): Flow<List<CyberResource>> = dao.searchResources(query).flowOn(Dispatchers.IO)

    fun getResourceById(id: String): Flow<CyberResource?> = dao.getResourceById(id).flowOn(Dispatchers.IO)

    suspend fun addResource(resource: CyberResource): Boolean {
        val finalResource = if (resource.id.isBlank()) {
            resource.copy(id = UUID.randomUUID().toString())
        } else {
            resource
        }
        // Save locally to Room
        dao.insertResource(finalResource)

        // Sync to Firebase in background
        return try {
            firebaseManager.publishResource(finalResource)
        } catch (e: Exception) {
            Log.w(tag, "Local save succeeded, cloud sync pending: ${e.message}")
            true
        }
    }

    suspend fun updateResource(resource: CyberResource) {
        dao.updateResource(resource)
        try {
            firebaseManager.publishResource(resource)
        } catch (e: Exception) {
            Log.w(tag, "Update saved locally: ${e.message}")
        }
    }

    suspend fun toggleFavorite(id: String, isFav: Boolean) {
        dao.setFavorite(id, isFav)
    }

    suspend fun deleteResource(id: String) {
        dao.deleteResourceById(id)
        try {
            firebaseManager.deleteResource(id)
        } catch (e: Exception) {
            Log.w(tag, "Deleted locally: ${e.message}")
        }
    }

    suspend fun clearLocalData() {
        dao.deleteAll()
    }
}
