package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.model.CyberResource

@Database(entities = [CyberResource::class], version = 1, exportSchema = false)
abstract class CyberDatabase : RoomDatabase() {
    abstract fun resourceDao(): CyberResourceDao

    companion object {
        @Volatile
        private var INSTANCE: CyberDatabase? = null

        fun getInstance(context: Context): CyberDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CyberDatabase::class.java,
                    "cyberhub_database.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
