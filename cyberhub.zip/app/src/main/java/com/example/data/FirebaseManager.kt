package com.example.data

import android.util.Log
import com.example.model.CyberResource
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirebaseManager {
    private val tag = "FirebaseManager"

    val auth: FirebaseAuth by lazy {
        try {
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.e(tag, "FirebaseAuth init error: ${e.message}")
            throw e
        }
    }

    val firestore: FirebaseFirestore by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.e(tag, "Firestore init error: ${e.message}")
            throw e
        }
    }

    /**
     * Checks if current logged in user has isAdmin == true in Firestore 'users/{uid}'.
     * Automatically registers user document with isAdmin: false if first time.
     */
    fun checkUserRole(onResult: (Boolean) -> Unit) {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            firestore.collection("users").document(currentUser.uid).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val adminStatus = document.getBoolean("isAdmin") ?: false
                        onResult(adminStatus)
                    } else {
                        // Create default user record in Firestore without overwriting existing data
                        val newUserData = mapOf(
                            "email" to (currentUser.email ?: ""),
                            "isAdmin" to false,
                            "createdAt" to System.currentTimeMillis()
                        )
                        firestore.collection("users").document(currentUser.uid)
                            .set(newUserData, SetOptions.merge())
                        onResult(false)
                    }
                }
                .addOnFailureListener { e ->
                    Log.w(tag, "checkUserRole failed: ${e.message}")
                    onResult(false)
                }
        } else {
            onResult(false)
        }
    }

    fun sendPasswordReset(email: String, onResult: (Boolean, String?) -> Unit) {
        if (email.isBlank()) {
            onResult(false, "Please enter your email address")
            return
        }
        auth.sendPasswordResetEmail(email.trim())
            .addOnSuccessListener {
                onResult(true, null)
            }
            .addOnFailureListener { e ->
                onResult(false, e.message)
            }
    }

    suspend fun checkUserRoleSuspend(): Boolean {
        val currentUser = auth.currentUser ?: return false
        return try {
            val doc = firestore.collection("users").document(currentUser.uid).get().await()
            if (doc.exists()) {
                doc.getBoolean("isAdmin") ?: false
            } else {
                val newUserData = mapOf(
                    "email" to (currentUser.email ?: ""),
                    "isAdmin" to false,
                    "createdAt" to System.currentTimeMillis()
                )
                firestore.collection("users").document(currentUser.uid).set(newUserData).await()
                false
            }
        } catch (e: Exception) {
            Log.w(tag, "checkUserRoleSuspend error: ${e.message}")
            false
        }
    }

    fun getCurrentUser(): FirebaseUser? = auth.currentUser

    /**
     * Real-time stream of all dynamic resources from Firestore collection 'resources'.
     * Updates automatically when admin adds/modifies content in Firebase.
     */
    fun getResourcesRealtime(): Flow<List<CyberResource>> = callbackFlow {
        var listener: ListenerRegistration? = null
        try {
            listener = firestore.collection("resources")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(tag, "Listen failed: ${error.message}")
                        trySend(emptyList())
                        return@addSnapshotListener
                    }

                    if (snapshot != null) {
                        val items = snapshot.documents.mapNotNull { doc ->
                            try {
                                val data = doc.data ?: return@mapNotNull null
                                CyberResource.fromFirestoreMap(doc.id, data)
                            } catch (ex: Exception) {
                                Log.e(tag, "Parsing error for ${doc.id}: ${ex.message}")
                                null
                            }
                        }
                        trySend(items)
                    }
                }
        } catch (e: Exception) {
            Log.e(tag, "Real-time subscription failed: ${e.message}")
            trySend(emptyList())
        }

        awaitClose {
            listener?.remove()
        }
    }

    /**
     * Publish a real resource dynamically to Firebase Firestore.
     */
    suspend fun publishResource(resource: CyberResource): Boolean {
        return try {
            val docRef = if (resource.id.isNotBlank()) {
                firestore.collection("resources").document(resource.id)
            } else {
                firestore.collection("resources").document()
            }
            val finalItem = if (resource.id.isBlank()) resource.copy(id = docRef.id) else resource
            docRef.set(finalItem.toFirestoreMap(), SetOptions.merge()).await()
            true
        } catch (e: Exception) {
            Log.e(tag, "Failed to publish resource to Firestore: ${e.message}", e)
            false
        }
    }

    /**
     * Delete resource from Firestore.
     */
    suspend fun deleteResource(id: String): Boolean {
        return try {
            firestore.collection("resources").document(id).delete().await()
            true
        } catch (e: Exception) {
            Log.e(tag, "Failed to delete from Firestore: ${e.message}")
            false
        }
    }
}
