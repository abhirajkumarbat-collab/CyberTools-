package com.example.data

import com.example.model.CyberResource

/**
 * Clean Default Data repository configuration.
 * All fake/dummy/mock items (such as fake ethical hacking courses, mock APK gallery items,
 * placeholder links, and mock bundles) have been strictly stripped out.
 * The app initializes with a clean, empty repository ready for dynamic server-side additions.
 */
object DefaultData {
    val initialResources: List<CyberResource> = emptyList()
}
