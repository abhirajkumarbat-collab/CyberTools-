package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CyberResource
import com.example.model.ResourceCategory
import com.example.ui.components.CyberEmptyState
import com.example.ui.components.CyberResourceCard
import com.example.ui.components.CyberSearchBar
import com.example.ui.theme.*
import com.example.viewmodel.CyberHubUiState

@Composable
fun HomeScreen(
    uiState: CyberHubUiState,
    onSearchChange: (String) -> Unit,
    onCategorySelect: (ResourceCategory) -> Unit,
    onResourceClick: (CyberResource) -> Unit,
    onFavoriteToggle: (CyberResource) -> Unit,
    onAddClick: () -> Unit,
    onNavigateToTab: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBg0),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Search Input
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                CyberSearchBar(
                    query = uiState.searchQuery,
                    onQueryChange = onSearchChange
                )
            }
        }

        // Hero Stats Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberBg2),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CyberHub Control",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = CyberTextPrimary
                            )
                            Text(
                                text = "Server-Driven Dynamic Architecture",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary
                            )
                        }
                        IconButton(
                            onClick = { onNavigateToTab(4) },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberBg3)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = "Admin Center",
                                tint = CyberPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        QuickStatItem(
                            count = "${uiState.allResources.size}",
                            label = "Live Items",
                            icon = Icons.Default.Layers,
                            tint = CyberPrimary,
                            onClick = { onNavigateToTab(1) }
                        )
                        QuickStatItem(
                            count = "${uiState.favoriteResources.size}",
                            label = "Saved",
                            icon = Icons.Default.Bookmark,
                            tint = CyberWarning,
                            onClick = { onNavigateToTab(3) }
                        )
                        QuickStatItem(
                            count = "10",
                            label = "Collections",
                            icon = Icons.Default.Category,
                            tint = CyberSecondary,
                            onClick = { onNavigateToTab(1) }
                        )
                        QuickStatItem(
                            count = "Active",
                            label = "Firebase",
                            icon = Icons.Default.CloudSync,
                            tint = CyberTertiary,
                            onClick = { onNavigateToTab(4) }
                        )
                    }
                }
            }
        }

        // Quick Category Navigation Tiles
        item {
            Text(
                text = "Browse Collections",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary,
                modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 8.dp)
            )

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val featuredCats = listOf(
                    ResourceCategory.COURSES,
                    ResourceCategory.APK_GALLERY,
                    ResourceCategory.METHODS,
                    ResourceCategory.TIPS,
                    ResourceCategory.BUNDLES,
                    ResourceCategory.VIDEOS
                )
                items(featuredCats) { cat ->
                    CategoryTile(
                        category = cat,
                        itemCount = uiState.allResources.count { it.category.equals(cat.id, ignoreCase = true) },
                        onClick = {
                            onCategorySelect(cat)
                            onNavigateToTab(1)
                        }
                    )
                }
            }
        }

        // CyberBot AI Quick Launcher Banner
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .clickable { onNavigateToTab(2) }
                    .border(1.dp, CyberPrimary.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                listOf(CyberBg2, CyberBg3)
                            )
                        )
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(listOf(CyberPrimary, CyberSecondary))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SmartToy,
                                contentDescription = null,
                                tint = CyberBg0,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "CyberBot Pro AI Mentor",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = CyberPrimary
                            )
                            Text(
                                text = "Ask questions, get packet analysis guidance, or search catalog",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = CyberPrimary
                        )
                    }
                }
            }
        }

        // Recent Real Resources Feed
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Live Resources Feed",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = CyberTextPrimary
                )
                TextButton(onClick = { onNavigateToTab(1) }) {
                    Text("View Catalog", color = CyberPrimary, style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        if (uiState.filteredResources.isEmpty()) {
            item {
                CyberEmptyState(
                    category = uiState.selectedCategory,
                    onAddClick = onAddClick,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else {
            items(uiState.filteredResources.take(6), key = { it.id }) { item ->
                val context = LocalContext.current
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                    CyberResourceCard(
                        resource = item,
                        onClick = { onResourceClick(item) },
                        onFavoriteToggle = { onFavoriteToggle(item) },
                        onOpenUrl = {
                            if (item.url.isNotBlank()) {
                                try {
                                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(item.url))
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    android.widget.Toast.makeText(context, "Could not open link", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun QuickStatItem(
    count: String,
    label: String,
    icon: ImageVector,
    tint: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = count, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = CyberTextPrimary)
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = CyberTextSecondary)
    }
}

@Composable
fun CategoryTile(
    category: ResourceCategory,
    itemCount: Int,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CyberBg2),
        modifier = Modifier
            .width(130.dp)
            .clickable(onClick = onClick)
            .border(1.dp, CyberLine1, RoundedCornerShape(12.dp))
            .testTag("category_tile_${category.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = category.emoji, fontSize = 24.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = category.displayName,
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary,
                maxLines = 1
            )
            Text(
                text = "$itemCount items",
                style = MaterialTheme.typography.labelSmall,
                color = CyberTextTertiary
            )
        }
    }
}
