package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.CyberResource
import com.example.model.ResourceCategory
import com.example.ui.components.CategoryFilterRow
import com.example.ui.components.CyberEmptyState
import com.example.ui.components.CyberResourceCard
import com.example.ui.components.CyberSearchBar
import com.example.ui.theme.*
import com.example.viewmodel.CyberHubUiState

@Composable
fun CatalogScreen(
    uiState: CyberHubUiState,
    onSearchChange: (String) -> Unit,
    onCategorySelect: (ResourceCategory) -> Unit,
    onResourceClick: (CyberResource) -> Unit,
    onFavoriteToggle: (CyberResource) -> Unit,
    onAddClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBg0)
    ) {
        // Search
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            CyberSearchBar(
                query = uiState.searchQuery,
                onQueryChange = onSearchChange
            )
        }

        // Category Filter Chips
        CategoryFilterRow(
            selectedCategory = uiState.selectedCategory,
            onCategorySelected = onCategorySelect,
            modifier = Modifier.padding(vertical = 6.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "${uiState.selectedCategory.displayName} (${uiState.filteredResources.size})",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary
            )
            Text(
                text = "Real-time Sync Active",
                style = MaterialTheme.typography.labelSmall,
                color = CyberTertiary
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("catalog_list"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
        ) {
            if (uiState.filteredResources.isEmpty()) {
                item {
                    CyberEmptyState(
                        category = uiState.selectedCategory,
                        onAddClick = onAddClick,
                        modifier = Modifier.padding(top = 40.dp)
                    )
                }
            } else {
                items(uiState.filteredResources, key = { it.id }) { item ->
                    Box(modifier = Modifier.padding(vertical = 6.dp)) {
                        CyberResourceCard(
                            resource = item,
                            onClick = { onResourceClick(item) },
                            onFavoriteToggle = { onFavoriteToggle(item) },
                            onOpenUrl = {
                                if (item.url.isNotBlank()) {
                                    try {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(item.url))
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Could not open link", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        )
                    }
                }
            }

            // Bottom space for navigation bar
            item {
                Spacer(modifier = Modifier.height(90.dp))
            }
        }
    }
}
