package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CyberDarkColorScheme = darkColorScheme(
    primary = CyberPrimary,
    onPrimary = Color(0xFF05070D),
    primaryContainer = CyberBg3,
    onPrimaryContainer = CyberPrimary,
    secondary = CyberSecondary,
    onSecondary = Color(0xFF05070D),
    secondaryContainer = CyberBg4,
    onSecondaryContainer = CyberSecondary,
    tertiary = CyberTertiary,
    onTertiary = Color(0xFF05070D),
    background = CyberBg0,
    onBackground = CyberTextPrimary,
    surface = CyberBg1,
    onSurface = CyberTextPrimary,
    surfaceVariant = CyberBg2,
    onSurfaceVariant = CyberTextSecondary,
    outline = CyberLine2,
    outlineVariant = CyberLine1,
    error = CyberDanger,
    onError = Color.White
)

private val CyberLightColorScheme = lightColorScheme(
    primary = Color(0xFF007799),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD0F4FF),
    onPrimaryContainer = Color(0xFF00202A),
    secondary = Color(0xFF7523C4),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF1DEFF),
    onSecondaryContainer = Color(0xFF27004B),
    tertiary = Color(0xFF00875A),
    onTertiary = Color.White,
    background = Color(0xFFF6F8FA),
    onBackground = Color(0xFF0F1421),
    surface = Color.White,
    onSurface = Color(0xFF0F1421),
    surfaceVariant = Color(0xFFE9EDF5),
    onSurfaceVariant = Color(0xFF475266),
    outline = Color(0xFFCBD5E1),
    outlineVariant = Color(0xFFE2E8F0),
    error = Color(0xFFD92D20),
    onError = Color.White
)

@Composable
fun CyberHubTheme(
    darkTheme: Boolean = true, // Default to cyberpunk dark mode
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) CyberDarkColorScheme else CyberLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Retain alias for backward-compatibility with tests or starter code
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    CyberHubTheme(darkTheme = darkTheme, content = content)
}
