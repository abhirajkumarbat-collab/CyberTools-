package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.VnVideoEditorCard
import com.example.ui.theme.*
import com.example.viewmodel.CyberHubUiState
import com.example.viewmodel.CyberHubViewModel

enum class AdminTab(val title: String, val icon: ImageVector) {
    DASHBOARD("Overview", Icons.Default.Dashboard),
    BULK_IMPORT("Bulk Import", Icons.Default.ElectricBolt),
    QUEUE("Publish Queue", Icons.Default.Schedule),
    AUTO_PUBLISH("Auto-Publish", Icons.Default.RocketLaunch),
    NOTIFICATIONS("Notifications", Icons.Default.Notifications),
    FLAGS("Feature Flags", Icons.Default.Tune),
    VIDEO_STUDIO("Video Studio", Icons.Default.VideoLibrary),
    MEDIA("Media Library", Icons.Default.PhotoLibrary),
    CONFIG_BACKUP("Config & Backup", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    uiState: CyberHubUiState,
    viewModel: CyberHubViewModel? = null,
    onOpenAddDialog: () -> Unit,
    onBulkImport: (rawText: String, category: ResourceCategory) -> Unit,
    onClearLocalData: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var currentTab by remember { mutableStateOf(AdminTab.DASHBOARD) }

    // Dialog state for previewing queue items
    var previewQueueItem by remember { mutableStateOf<QueueItem?>(null) }
    var editDateQueueItem by remember { mutableStateOf<QueueItem?>(null) }
    var newDateInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBg0)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Admin Header Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberBg2),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.linearGradient(listOf(CyberPrimary, CyberSecondary))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "Admin",
                                tint = CyberBg0,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = uiState.appConfig.appName,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = CyberTextPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = CyberPrimary.copy(alpha = 0.2f),
                                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(CyberPrimary, CyberSecondary)))
                                ) {
                                    Text(
                                        text = uiState.appConfig.tagline,
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                                        color = CyberPrimary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Admin: ${uiState.currentUserEmail ?: "Firebase Admin"} · Firestore Active",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                color = CyberTertiary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onOpenAddDialog,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBg0),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier.weight(1f).height(42.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Resource", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                Toast.makeText(context, "Synced with Firebase Firestore & Room cache", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberPrimary),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier.height(42.dp)
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sync", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Horizontal Section Selector Tabs
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(AdminTab.entries) { tab ->
                    val isSelected = currentTab == tab
                    val badgeCount = when (tab) {
                        AdminTab.QUEUE -> uiState.publishQueue.count { it.status == "pending" }
                        AdminTab.NOTIFICATIONS -> uiState.adminNotifications.size
                        else -> 0
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) CyberPrimary else CyberBg2,
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.linearGradient(
                                if (isSelected) listOf(CyberPrimary, CyberSecondary) else listOf(CyberLine1, CyberLine1)
                            )
                        ),
                        modifier = Modifier.clickable { currentTab = tab }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = null,
                                tint = if (isSelected) CyberBg0 else CyberTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = tab.title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 11.sp
                                ),
                                color = if (isSelected) CyberBg0 else CyberTextPrimary
                            )
                            if (badgeCount > 0) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(if (isSelected) CyberBg0 else CyberWarning)
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = "$badgeCount",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) CyberPrimary else CyberBg0
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Tab Content Section
        when (currentTab) {
            AdminTab.DASHBOARD -> {
                item { DashboardOverviewSection(uiState = uiState, onSwitchTab = { currentTab = it }) }
                item { LiveActivityTimelineSection(uiState = uiState, onClearLogs = { viewModel?.clearActivityLogs() }) }
            }
            AdminTab.BULK_IMPORT -> {
                item {
                    BulkImportWizardSection(
                        uiState = uiState,
                        onAddToQueue = { items -> viewModel?.addBulkToQueue(items) },
                        onPublishDirect = { raw, cat -> onBulkImport(raw, cat) }
                    )
                }
            }
            AdminTab.QUEUE -> {
                item {
                    PublishQueueSection(
                        uiState = uiState,
                        onAutoSchedule = { viewModel?.autoScheduleQueue() },
                        onPublishDueNow = { viewModel?.publishDueNow() },
                        onPublishItem = { item -> viewModel?.publishQueueItem(item) },
                        onDeleteItem = { id -> viewModel?.deleteQueueItem(id) },
                        onClearAll = { viewModel?.clearQueue() },
                        onPreview = { item -> previewQueueItem = item },
                        onEditDate = { item ->
                            editDateQueueItem = item
                            newDateInput = item.scheduledDate.ifEmpty { AdminDateUtils.getTodayString() }
                        }
                    )
                }
            }
            AdminTab.AUTO_PUBLISH -> {
                item {
                    AutoPublishSettingsSection(
                        uiState = uiState,
                        onToggleAutoPublish = { viewModel?.toggleAutoPublish(it) },
                        onUpdateItemsPerDay = { viewModel?.updateItemsPerDay(it) },
                        onPublishDueNow = { viewModel?.publishDueNow() },
                        onAutoSchedule = { viewModel?.autoScheduleQueue() }
                    )
                }
            }
            AdminTab.NOTIFICATIONS -> {
                item {
                    NotificationsBroadcasterSection(
                        uiState = uiState,
                        onSendNotification = { title, body, link, aud, img ->
                            viewModel?.sendAdminNotification(title, body, link, aud, img)
                        },
                        onDeleteNotification = { id -> viewModel?.deleteNotification(id) }
                    )
                }
            }
            AdminTab.FLAGS -> {
                item {
                    FeatureFlagsSection(
                        uiState = uiState,
                        onToggle = { key, value -> viewModel?.toggleFeatureFlag(key, value) }
                    )
                }
            }
            AdminTab.VIDEO_STUDIO -> {
                item { VnVideoEditorCard() }
            }
            AdminTab.MEDIA -> {
                item {
                    MediaLibrarySection(
                        uiState = uiState,
                        onAddMedia = { name, url, type -> viewModel?.addMediaItem(name, url, type) },
                        onDeleteMedia = { id -> viewModel?.deleteMediaItem(id) }
                    )
                }
            }
            AdminTab.CONFIG_BACKUP -> {
                item {
                    AppConfigAndBackupSection(
                        uiState = uiState,
                        onSaveConfig = { config -> viewModel?.saveAppConfig(config) },
                        onClearLocalDb = onClearLocalData
                    )
                }
            }
        }
    }

    // Queue Item Preview Dialog
    previewQueueItem?.let { item ->
        AlertDialog(
            onDismissRequest = { previewQueueItem = null },
            containerColor = CyberBg1,
            title = {
                Text(text = item.title, style = MaterialTheme.typography.titleMedium, color = CyberTextPrimary)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Collection: ${item.collection.uppercase()}", color = CyberPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("Platform: ${item.platformIcon} ${item.platform}", color = CyberTextSecondary, fontSize = 12.sp)
                    Text("Schedule: ${item.scheduledDate.ifEmpty { "Not scheduled" }}", color = CyberWarning, fontSize = 12.sp)
                    Text("URL: ${item.url}", color = CyberTextSecondary, fontSize = 11.sp)
                    Text("Description: ${item.description}", color = CyberTextPrimary, fontSize = 12.sp)
                    Text("Copyright: ${item.copyright}", color = CyberTertiary, fontSize = 10.sp)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel?.publishQueueItem(item)
                        previewQueueItem = null
                        Toast.makeText(context, "Published to live catalog!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSuccess, contentColor = CyberBg0)
                ) {
                    Text("Publish Now")
                }
            },
            dismissButton = {
                TextButton(onClick = { previewQueueItem = null }) {
                    Text("Close", color = CyberTextSecondary)
                }
            }
        )
    }

    // Edit Date Dialog
    editDateQueueItem?.let { item ->
        AlertDialog(
            onDismissRequest = { editDateQueueItem = null },
            containerColor = CyberBg1,
            title = { Text("Set Schedule Date", color = CyberTextPrimary) },
            text = {
                Column {
                    Text("Format: YYYY-MM-DD", fontSize = 11.sp, color = CyberTextSecondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newDateInput,
                        onValueChange = { newDateInput = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newDateInput.isNotBlank()) {
                            viewModel?.updateQueueItemDate(item.id, newDateInput.trim())
                            editDateQueueItem = null
                            Toast.makeText(context, "Date updated to $newDateInput", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBg0)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { editDateQueueItem = null }) {
                    Text("Cancel", color = CyberTextSecondary)
                }
            }
        )
    }
}

// -------------------------------------------------------------
// 1. DASHBOARD OVERVIEW SECTION
// -------------------------------------------------------------
@Composable
private fun DashboardOverviewSection(
    uiState: CyberHubUiState,
    onSwitchTab: (AdminTab) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberBg2),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "📊 Content Breakdown & Live Metrics",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Stat Cards Grid
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricStatCard("Courses", "${uiState.allResources.count { it.category.equals("courses", ignoreCase = true) }}", "🎓", CyberPrimary, Modifier.weight(1f))
                    MetricStatCard("APKs", "${uiState.allResources.count { it.category.equals("apks", ignoreCase = true) }}", "📱", CyberSecondary, Modifier.weight(1f))
                    MetricStatCard("Methods", "${uiState.allResources.count { it.category.equals("methods", ignoreCase = true) }}", "🔧", CyberSuccess, Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricStatCard("Tips", "${uiState.allResources.count { it.category.equals("tips", ignoreCase = true) }}", "💡", CyberWarning, Modifier.weight(1f))
                    MetricStatCard("Videos", "${uiState.allResources.count { it.category.equals("videos", ignoreCase = true) }}", "🎬", CyberDanger, Modifier.weight(1f))
                    MetricStatCard("Bundles", "${uiState.allResources.count { it.category.equals("bundles", ignoreCase = true) }}", "📦", CyberTertiary, Modifier.weight(1f))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Queue Highlights Card
            val pendingQueue = uiState.publishQueue.count { it.status == "pending" }
            val todayStr = AdminDateUtils.getTodayString()
            val dueToday = uiState.publishQueue.count { it.status == "pending" && it.scheduledDate == todayStr }

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CyberBg1),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSwitchTab(AdminTab.QUEUE) }
                    .border(1.dp, CyberLine2, RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "📅 Publish Queue Status",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = CyberTextPrimary
                        )
                        Text(
                            text = "$pendingQueue pending items · $dueToday due today",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (dueToday > 0) CyberWarning else CyberPrimary.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = if (dueToday > 0) "⚡ DUE NOW ($dueToday)" else "QUEUE ($pendingQueue)",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
                            color = if (dueToday > 0) CyberBg0 else CyberPrimary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricStatCard(
    label: String,
    count: String,
    emoji: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = CyberBg1,
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(accentColor.copy(alpha = 0.5f), CyberLine1))),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = emoji, fontSize = 16.sp)
            Text(text = count, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = accentColor)
            Text(text = label, fontSize = 10.sp, color = CyberTextSecondary, maxLines = 1)
        }
    }
}

// -------------------------------------------------------------
// 2. BULK IMPORT WIZARD WITH AI PARSING
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BulkImportWizardSection(
    uiState: CyberHubUiState,
    onAddToQueue: (List<QueueItem>) -> Unit,
    onPublishDirect: (String, ResourceCategory) -> Unit
) {
    val context = LocalContext.current
    var rawInput by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(ResourceCategory.METHODS) }
    var categoryDropdownOpen by remember { mutableStateOf(false) }
    var bulkTag by remember { mutableStateOf("cyber-2026") }
    var analyzedItems by remember { mutableStateOf<List<QueueItem>>(emptyList()) }
    var selectedItemIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var isAnalyzing by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberBg2),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = CyberWarning)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "⚡ Bulk Import Wizard",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = CyberTextPrimary
                    )
                    Text(
                        text = "Paste 100+ links · AI detects platform, tags, and creates scheduled queue items",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Category & Tag Selectors
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = "${selectedCategory.emoji} ${selectedCategory.displayName}",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Collection") },
                        trailingIcon = {
                            IconButton(onClick = { categoryDropdownOpen = !categoryDropdownOpen }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = CyberPrimary)
                            }
                        },
                        modifier = Modifier.fillMaxWidth().clickable { categoryDropdownOpen = true }
                    )
                    DropdownMenu(
                        expanded = categoryDropdownOpen,
                        onDismissRequest = { categoryDropdownOpen = false }
                    ) {
                        ResourceCategory.entries.filter { it != ResourceCategory.ALL }.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text("${cat.emoji} ${cat.displayName}") },
                                onClick = {
                                    selectedCategory = cat
                                    categoryDropdownOpen = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = bulkTag,
                    onValueChange = { bulkTag = it },
                    label = { Text("Bulk Tag") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = rawInput,
                onValueChange = { rawInput = it },
                label = { Text("Paste URLs (one per line)") },
                placeholder = {
                    Text("https://drive.google.com/file/d/...\nhttps://youtube.com/watch?v=...\nhttps://t.me/cybersec_tools\nhttps://github.com/nmap/nmap\nhttps://example.com/pentest.pdf")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons: Analyze All with AI
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        val lines = rawInput.lines().map { it.trim() }.filter { it.isNotBlank() }
                        if (lines.isNotEmpty()) {
                            isAnalyzing = true
                            val items = lines.map { url ->
                                analyzeUrl(url, selectedCategory, bulkTag)
                            }
                            analyzedItems = items
                            selectedItemIds = items.map { it.id }.toSet()
                            isAnalyzing = false
                            Toast.makeText(context, "${items.size} links analyzed!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    enabled = rawInput.isNotBlank() && !isAnalyzing,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBg0),
                    modifier = Modifier.weight(1f).height(44.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("✨ Analyze with AI", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        rawInput = ""
                        analyzedItems = emptyList()
                        selectedItemIds = emptySet()
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberDanger),
                    modifier = Modifier.height(44.dp)
                ) {
                    Text("Clear")
                }
            }

            // Analyzed Items Preview List
            if (analyzedItems.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = CyberLine1)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "✓ ${selectedItemIds.size}/${analyzedItems.size} Selected",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = CyberPrimary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton(
                            onClick = { selectedItemIds = analyzedItems.map { it.id }.toSet() },
                            contentPadding = PaddingValues(horizontal = 6.dp)
                        ) {
                            Text("All", fontSize = 11.sp, color = CyberTextPrimary)
                        }
                        TextButton(
                            onClick = { selectedItemIds = emptySet() },
                            contentPadding = PaddingValues(horizontal = 6.dp)
                        ) {
                            Text("None", fontSize = 11.sp, color = CyberTextSecondary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    analyzedItems.take(5).forEach { item ->
                        val isChecked = item.id in selectedItemIds
                        Card(
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = CyberBg1),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedItemIds = if (isChecked) selectedItemIds - item.id else selectedItemIds + item.id
                                }
                                .border(1.dp, if (isChecked) CyberPrimary else CyberLine2, RoundedCornerShape(8.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { check ->
                                        selectedItemIds = if (check) selectedItemIds + item.id else selectedItemIds - item.id
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = CyberPrimary)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = CyberTextPrimary, maxLines = 1)
                                    Text("${item.platformIcon} ${item.platform} · ${item.url}", fontSize = 10.sp, color = CyberTextSecondary, maxLines = 1)
                                }
                            }
                        }
                    }
                    if (analyzedItems.size > 5) {
                        Text(
                            text = "+ ${analyzedItems.size - 5} more items parsed and ready",
                            fontSize = 11.sp,
                            color = CyberTextSecondary,
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val itemsToAdd = analyzedItems.filter { it.id in selectedItemIds }
                            onAddToQueue(itemsToAdd)
                            Toast.makeText(context, "${itemsToAdd.size} items added to Publish Queue!", Toast.LENGTH_SHORT).show()
                            rawInput = ""
                            analyzedItems = emptyList()
                            selectedItemIds = emptySet()
                        },
                        enabled = selectedItemIds.isNotEmpty(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberSuccess, contentColor = CyberBg0),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("📅 Add to Queue", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            onPublishDirect(rawInput, selectedCategory)
                            rawInput = ""
                            analyzedItems = emptyList()
                            selectedItemIds = emptySet()
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberTertiary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("🚀 Publish Now", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// URL analysis logic based on the user's HTML engine
private fun analyzeUrl(url: String, defaultCat: ResourceCategory, bulkTag: String): QueueItem {
    val u = url.lowercase()
    val platform = when {
        "youtube.com" in u || "youtu.be" in u -> "YouTube" to "▶️"
        "drive.google.com" in u -> "Google Drive" to "📁"
        "mega.nz" in u -> "MEGA" to "☁️"
        "t.me" in u || "telegram" in u -> "Telegram" to "✈️"
        "instagram.com" in u -> "Instagram" to "📷"
        "github.com" in u -> "GitHub" to "💻"
        ".apk" in u -> "Android APK" to "📱"
        ".pdf" in u -> "PDF Document" to "📄"
        ".zip" in u || ".rar" in u -> "Archive" to "🗜️"
        else -> "Web Resource" to "🌐"
    }

    val inferredCat = when {
        ".apk" in u -> ResourceCategory.APK_GALLERY.id
        "youtube.com" in u || "youtu.be" in u || ".mp4" in u -> ResourceCategory.VIDEOS.id
        "drive.google.com" in u -> ResourceCategory.BUNDLES.id
        ".pdf" in u || ".doc" in u -> ResourceCategory.FILES.id
        else -> defaultCat.id
    }

    val cleanName = url.substringAfterLast("/").substringBefore("?").replace("[-_]".toRegex(), " ").take(40)
    val title = if (cleanName.isBlank() || cleanName.length < 3) "${platform.second} ${platform.first} Resource" else "${platform.second} $cleanName"

    return QueueItem(
        title = title,
        collection = inferredCat,
        url = url,
        description = "${platform.second} ${platform.first} security asset. Auto-parsed by CyberHub Admin v9 engine.",
        platform = platform.first,
        platformIcon = platform.second,
        tags = listOf(bulkTag, platform.first.lowercase()).filter { it.isNotBlank() },
        scheduledDate = ""
    )
}

// -------------------------------------------------------------
// 3. PUBLISH QUEUE & SCHEDULER SECTION
// -------------------------------------------------------------
@Composable
private fun PublishQueueSection(
    uiState: CyberHubUiState,
    onAutoSchedule: () -> Unit,
    onPublishDueNow: () -> Unit,
    onPublishItem: (QueueItem) -> Unit,
    onDeleteItem: (String) -> Unit,
    onClearAll: () -> Unit,
    onPreview: (QueueItem) -> Unit,
    onEditDate: (QueueItem) -> Unit
) {
    val context = LocalContext.current
    val today = AdminDateUtils.getTodayString()
    val queue = uiState.publishQueue
    val pendingCount = queue.count { it.status == "pending" }
    val dueCount = queue.count { it.status == "pending" && it.scheduledDate.isNotBlank() && it.scheduledDate <= today }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberBg2),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "📅 Publish Queue",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = CyberTextPrimary
                    )
                    Text(
                        text = "$pendingCount pending · $dueCount due today",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberTextSecondary
                    )
                }
                if (queue.isNotEmpty()) {
                    IconButton(onClick = onClearAll, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Clear Queue", tint = CyberDanger, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Row
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        onAutoSchedule()
                        Toast.makeText(context, "Queue auto-scheduled evenly across future dates!", Toast.LENGTH_SHORT).show()
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBg0),
                    modifier = Modifier.weight(1f).height(40.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Auto-Schedule", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        onPublishDueNow()
                        Toast.makeText(context, "All due items published to Firestore!", Toast.LENGTH_SHORT).show()
                    },
                    enabled = dueCount > 0,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSuccess, contentColor = CyberBg0),
                    modifier = Modifier.weight(1f).height(40.dp)
                ) {
                    Icon(Icons.Default.RocketLaunch, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Publish Due ($dueCount)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (queue.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📅", fontSize = 36.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Queue is empty", fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                        Text("Add items via Bulk Import to schedule releases", fontSize = 11.sp, color = CyberTextSecondary)
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    queue.forEachIndexed { idx, item ->
                        val isDue = item.status == "pending" && item.scheduledDate.isNotBlank() && item.scheduledDate <= today
                        val isPublished = item.status == "published"

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = CyberBg1),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, if (isDue) CyberWarning else CyberLine2, RoundedCornerShape(12.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(if (isPublished) CyberSuccess else CyberPrimary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("${idx + 1}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberBg0)
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = CyberTextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("${item.platformIcon} ${item.platform}", fontSize = 10.sp, color = CyberTextSecondary)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("·", fontSize = 10.sp, color = CyberTextSecondary)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(item.collection.uppercase(), fontSize = 10.sp, color = CyberPrimary, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    if (isDue) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = CyberWarning.copy(alpha = 0.2f)
                                        ) {
                                            Text("DUE NOW", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = CyberWarning, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                        }
                                    } else if (isPublished) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = CyberSuccess.copy(alpha = 0.2f)
                                        ) {
                                            Text("PUBLISHED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = CyberSuccess, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (item.scheduledDate.isNotBlank()) "📅 ${item.scheduledDate}" else "📅 Not scheduled",
                                        fontSize = 11.sp,
                                        color = if (item.scheduledDate.isNotBlank()) CyberPrimary else CyberTextSecondary
                                    )

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        IconButton(onClick = { onEditDate(item) }, modifier = Modifier.size(28.dp)) {
                                            Icon(Icons.Default.EditCalendar, contentDescription = "Edit Date", tint = CyberPrimary, modifier = Modifier.size(16.dp))
                                        }
                                        IconButton(onClick = { onPreview(item) }, modifier = Modifier.size(28.dp)) {
                                            Icon(Icons.Default.Visibility, contentDescription = "Preview", tint = CyberTextSecondary, modifier = Modifier.size(16.dp))
                                        }
                                        IconButton(onClick = { onPublishItem(item) }, modifier = Modifier.size(28.dp)) {
                                            Icon(Icons.Default.RocketLaunch, contentDescription = "Publish", tint = CyberSuccess, modifier = Modifier.size(16.dp))
                                        }
                                        IconButton(onClick = { onDeleteItem(item.id) }, modifier = Modifier.size(28.dp)) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CyberDanger, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 4. AUTO-PUBLISH SETTINGS SECTION
// -------------------------------------------------------------
@Composable
private fun AutoPublishSettingsSection(
    uiState: CyberHubUiState,
    onToggleAutoPublish: (Boolean) -> Unit,
    onUpdateItemsPerDay: (Int) -> Unit,
    onPublishDueNow: () -> Unit,
    onAutoSchedule: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberBg2),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "🚀 Auto-Publish & Daily Scheduler",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary
            )
            Text(
                text = "Configure automated releases. When enabled, items due on the current day publish automatically.",
                style = MaterialTheme.typography.labelSmall,
                color = CyberTextSecondary
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Master Switch
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberBg1, RoundedCornerShape(10.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Auto-Publish on App Launch", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CyberTextPrimary)
                    Text("Automatically releases due queue items", fontSize = 11.sp, color = CyberTextSecondary)
                }
                Switch(
                    checked = uiState.autoPublishEnabled,
                    onCheckedChange = onToggleAutoPublish,
                    colors = SwitchDefaults.colors(checkedThumbColor = CyberPrimary, checkedTrackColor = CyberPrimary.copy(alpha = 0.4f))
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Items per day stepper
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberBg1, RoundedCornerShape(10.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Items Per Day (Auto-Scheduler)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CyberTextPrimary)
                    Text("Number of items assigned to each date", fontSize = 11.sp, color = CyberTextSecondary)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { onUpdateItemsPerDay(uiState.itemsPerDay - 1) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Text("-", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = CyberPrimary)
                    }
                    Text(
                        text = "${uiState.itemsPerDay}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    IconButton(
                        onClick = { onUpdateItemsPerDay(uiState.itemsPerDay + 1) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = CyberPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Stats row
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricStatCard("Total Auto-Published", "${uiState.totalAutoPublished}", "🚀", CyberSuccess, Modifier.weight(1f))
                MetricStatCard("Pending in Queue", "${uiState.publishQueue.count { it.status == "pending" }}", "📅", CyberWarning, Modifier.weight(1f))
            }
        }
    }
}

// -------------------------------------------------------------
// 5. NOTIFICATIONS BROADCASTER SECTION
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotificationsBroadcasterSection(
    uiState: CyberHubUiState,
    onSendNotification: (String, String, String, String, String) -> Unit,
    onDeleteNotification: (String) -> Unit
) {
    val context = LocalContext.current
    var notifTitle by remember { mutableStateOf("") }
    var notifBody by remember { mutableStateOf("") }
    var notifLink by remember { mutableStateOf("cyberhub://course/latest") }
    var notifAudience by remember { mutableStateOf("All Users") }
    var audienceDropdownOpen by remember { mutableStateOf(false) }
    var notifImage by remember { mutableStateOf("") }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberBg2),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "🔔 Push Notifications Broadcaster",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary
            )
            Text(
                text = "Broadcast push messages to all app users with deep-links",
                style = MaterialTheme.typography.labelSmall,
                color = CyberTextSecondary
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = notifTitle,
                onValueChange = { notifTitle = it },
                label = { Text("Notification Title") },
                placeholder = { Text("⚡ New Zero-Day Method Released!") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = notifBody,
                onValueChange = { notifBody = it },
                label = { Text("Message Body") },
                placeholder = { Text("Learn how to defend against modern API attacks with our latest hands-on guide.") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = notifLink,
                    onValueChange = { notifLink = it },
                    label = { Text("Deep Link") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                Box(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = notifAudience,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Audience") },
                        trailingIcon = {
                            IconButton(onClick = { audienceDropdownOpen = !audienceDropdownOpen }) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = CyberPrimary)
                            }
                        },
                        modifier = Modifier.fillMaxWidth().clickable { audienceDropdownOpen = true }
                    )
                    DropdownMenu(
                        expanded = audienceDropdownOpen,
                        onDismissRequest = { audienceDropdownOpen = false }
                    ) {
                        listOf("All Users", "Active Users", "New Users", "Subscribers").forEach { aud ->
                            DropdownMenuItem(
                                text = { Text(aud) },
                                onClick = {
                                    notifAudience = aud
                                    audienceDropdownOpen = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Phone Notification Preview Mockup
            Text("📱 Live Phone Mockup Preview:", style = MaterialTheme.typography.labelSmall, color = CyberTertiary)
            Spacer(modifier = Modifier.height(6.dp))

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CyberBg1),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberLine2, RoundedCornerShape(12.dp))
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(CyberPrimary, CyberSecondary))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = CyberBg0, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(uiState.appConfig.appName, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CyberTextSecondary)
                            Text(" · now", fontSize = 9.sp, color = CyberTertiary)
                        }
                        Text(
                            text = notifTitle.ifEmpty { "Notification Title" },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextPrimary
                        )
                        Text(
                            text = notifBody.ifEmpty { "Notification body message preview..." },
                            fontSize = 11.sp,
                            color = CyberTextSecondary,
                            maxLines = 2
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = {
                    if (notifTitle.isNotBlank() && notifBody.isNotBlank()) {
                        onSendNotification(notifTitle.trim(), notifBody.trim(), notifLink.trim(), notifAudience, notifImage)
                        notifTitle = ""
                        notifBody = ""
                        Toast.makeText(context, "Notification dispatched to Firebase!", Toast.LENGTH_SHORT).show()
                    }
                },
                enabled = notifTitle.isNotBlank() && notifBody.isNotBlank(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBg0),
                modifier = Modifier.fillMaxWidth().height(44.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("🚀 Broadcast Notification", fontWeight = FontWeight.Bold)
            }

            if (uiState.adminNotifications.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text("Sent Notifications (${uiState.adminNotifications.size})", style = MaterialTheme.typography.titleSmall, color = CyberTextPrimary)
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    uiState.adminNotifications.forEach { n ->
                        Card(
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = CyberBg1),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(n.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = CyberTextPrimary)
                                    Text(n.body, fontSize = 11.sp, color = CyberTextSecondary, maxLines = 1)
                                    Text("${AdminDateUtils.formatDisplayDate(n.timestamp)} · ${n.audience}", fontSize = 9.sp, color = CyberTertiary)
                                }
                                IconButton(onClick = { onDeleteNotification(n.id) }, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Default.Delete, contentDescription = null, tint = CyberDanger, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 6. FEATURE FLAGS REMOTE MANAGER
// -------------------------------------------------------------
@Composable
private fun FeatureFlagsSection(
    uiState: CyberHubUiState,
    onToggle: (String, Boolean) -> Unit
) {
    val flags = listOf(
        Triple("ai_assistant", "AI Assistant (CyberBot Pro)", "🤖"),
        Triple("apk_gallery", "APK Gallery & Direct Downloads", "📱"),
        Triple("folders", "Folder Browsing Section", "📂"),
        Triple("files_section", "Downloadable Files & Docs", "📄"),
        Triple("long_videos", "Full Course Video Player", "🎬"),
        Triple("short_videos", "Security Shorts & Reels", "⚡"),
        Triple("bundles_section", "Drive Bundles", "📦"),
        Triple("messages_section", "In-App Announcements & Popups", "💬"),
        Triple("daily_highlights", "Daily Highlights & News", "📰"),
        Triple("promotions", "Promotions & Banner Strips", "🎁"),
        Triple("offline_mode", "Offline Content Caching", "📡"),
        Triple("dark_mode_default", "Dark Mode as Default", "🌙")
    )

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberBg2),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "🚩 Remote Feature Flags",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary
            )
            Text(
                text = "Enable or disable modules dynamically for user builds",
                style = MaterialTheme.typography.labelSmall,
                color = CyberTextSecondary
            )

            Spacer(modifier = Modifier.height(14.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                flags.forEach { (key, title, icon) ->
                    val isEnabled = uiState.featureFlags[key] ?: true
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CyberBg1, RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Text(icon, fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = CyberTextPrimary)
                        }
                        Switch(
                            checked = isEnabled,
                            onCheckedChange = { onToggle(key, it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = CyberPrimary, checkedTrackColor = CyberPrimary.copy(alpha = 0.4f))
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 7. MEDIA LIBRARY SECTION
// -------------------------------------------------------------
@Composable
private fun MediaLibrarySection(
    uiState: CyberHubUiState,
    onAddMedia: (String, String, String) -> Unit,
    onDeleteMedia: (String) -> Unit
) {
    val context = LocalContext.current
    var mediaName by remember { mutableStateOf("") }
    var mediaUrl by remember { mutableStateOf("") }
    var mediaType by remember { mutableStateOf("image") }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberBg2),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "🖼️ Media Library",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary
            )
            Text(
                text = "Store external logos, posters, and setup clips",
                style = MaterialTheme.typography.labelSmall,
                color = CyberTextSecondary
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = mediaName,
                    onValueChange = { mediaName = it },
                    label = { Text("Asset Name") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = mediaUrl,
                    onValueChange = { mediaUrl = it },
                    label = { Text("Asset URL") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    if (mediaName.isNotBlank() && mediaUrl.isNotBlank()) {
                        val isVid = mediaUrl.endsWith(".mp4") || mediaUrl.contains("youtube")
                        onAddMedia(mediaName.trim(), mediaUrl.trim(), if (isVid) "video" else "image")
                        mediaName = ""
                        mediaUrl = ""
                        Toast.makeText(context, "Asset added to library!", Toast.LENGTH_SHORT).show()
                    }
                },
                enabled = mediaName.isNotBlank() && mediaUrl.isNotBlank(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBg0),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add to Media Library")
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (uiState.mediaLibrary.isEmpty()) {
                Text("No media added yet. Add URLs above.", fontSize = 11.sp, color = CyberTextSecondary)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    uiState.mediaLibrary.forEach { m ->
                        Card(
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = CyberBg1),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(m.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = CyberTextPrimary)
                                    Text(m.url, fontSize = 10.sp, color = CyberTextSecondary, maxLines = 1)
                                }
                                IconButton(onClick = { onDeleteMedia(m.id) }, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Default.Delete, contentDescription = null, tint = CyberDanger, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 8. APP CONFIG & BACKUP SECTION
// -------------------------------------------------------------
@Composable
private fun AppConfigAndBackupSection(
    uiState: CyberHubUiState,
    onSaveConfig: (AdminAppConfig) -> Unit,
    onClearLocalDb: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val config = uiState.appConfig

    var appName by remember { mutableStateOf(config.appName) }
    var tagline by remember { mutableStateOf(config.tagline) }
    var welcomeMessage by remember { mutableStateOf(config.welcomeMessage) }
    var maintenanceMode by remember { mutableStateOf(config.maintenanceMode) }
    var forceUpdate by remember { mutableStateOf(config.forceUpdate) }
    var minVersion by remember { mutableStateOf(config.minAppVersion) }
    var latestVersion by remember { mutableStateOf(config.latestAppVersion) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberBg2),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "⚙️ App Global Configuration",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = appName,
                    onValueChange = { appName = it },
                    label = { Text("App Name") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = tagline,
                    onValueChange = { tagline = it },
                    label = { Text("Tagline") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = welcomeMessage,
                onValueChange = { welcomeMessage = it },
                label = { Text("Welcome Banner Message") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Maintenance & Force Update switches
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberBg1, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Maintenance Mode", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = CyberTextPrimary)
                Switch(checked = maintenanceMode, onCheckedChange = { maintenanceMode = it })
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberBg1, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Force Update Required", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = CyberTextPrimary)
                Switch(checked = forceUpdate, onCheckedChange = { forceUpdate = it })
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    val newConfig = config.copy(
                        appName = appName.trim(),
                        tagline = tagline.trim(),
                        welcomeMessage = welcomeMessage.trim(),
                        maintenanceMode = maintenanceMode,
                        forceUpdate = forceUpdate,
                        minAppVersion = minVersion.trim(),
                        latestAppVersion = latestVersion.trim()
                    )
                    onSaveConfig(newConfig)
                    Toast.makeText(context, "Global configuration saved to Firebase!", Toast.LENGTH_SHORT).show()
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBg0),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save Configuration")
            }

            Spacer(modifier = Modifier.height(18.dp))
            HorizontalDivider(color = CyberLine1)
            Spacer(modifier = Modifier.height(14.dp))

            // Database Backup & Cache
            Text("💾 Backup & Database Management", style = MaterialTheme.typography.titleSmall, color = CyberTextPrimary)
            Spacer(modifier = Modifier.height(6.dp))
            Text("Export complete catalog JSON or reset local Room cache.", fontSize = 11.sp, color = CyberTextSecondary)
            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        val json = uiState.allResources.joinToString(separator = ",\n", prefix = "[\n", postfix = "\n]") { r ->
                            "  {\"id\":\"${r.id}\",\"title\":\"${r.title}\",\"category\":\"${r.category}\",\"url\":\"${r.url}\"}"
                        }
                        clipboardManager.setText(AnnotatedString(json))
                        Toast.makeText(context, "Full catalog backup copied to clipboard!", Toast.LENGTH_SHORT).show()
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberTertiary, contentColor = CyberBg0),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy Backup", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onClearLocalDb,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberDanger),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Clear Local DB", fontSize = 11.sp)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 9. LIVE ACTIVITY TIMELINE SECTION
// -------------------------------------------------------------
@Composable
private fun LiveActivityTimelineSection(
    uiState: CyberHubUiState,
    onClearLogs: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberBg2),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🕐 Live Activity Timeline",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = CyberTextPrimary
                )
                if (uiState.activityLogs.isNotEmpty()) {
                    TextButton(onClick = onClearLogs) {
                        Text("Clear", fontSize = 11.sp, color = CyberTextSecondary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                uiState.activityLogs.take(8).forEach { log ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CyberBg1, RoundedCornerShape(8.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(CyberBg3),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(log.icon, fontSize = 14.sp)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(log.action, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = CyberTextPrimary)
                            if (log.detail.isNotBlank()) {
                                Text(log.detail, fontSize = 10.sp, color = CyberTextSecondary, maxLines = 1)
                            }
                        }
                        Text(
                            text = AdminDateUtils.formatDisplayDate(log.timestamp),
                            fontSize = 9.sp,
                            color = CyberTertiary
                        )
                    }
                }
            }
        }
    }
}
