package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.CyberHubUiState
import com.example.viewmodel.CyberHubViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    viewModel: CyberHubViewModel,
    uiState: CyberHubUiState,
    onContinueToApp: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Sign In, 1 = Sign Up, 2 = Google/Phone, 3 = Guest
    val scrollState = rememberScrollState()

    // Sign In states
    var signInEmail by remember { mutableStateOf("") }
    var signInPassword by remember { mutableStateOf("") }
    var isSignInPasswordVisible by remember { mutableStateOf(false) }
    var isSigningIn by remember { mutableStateOf(false) }
    var signInError by remember { mutableStateOf<String?>(null) }

    // Sign Up states
    var signUpName by remember { mutableStateOf("") }
    var signUpEmail by remember { mutableStateOf("") }
    var signUpPassword by remember { mutableStateOf("") }
    var signUpConfirmPassword by remember { mutableStateOf("") }
    var isSignUpPasswordVisible by remember { mutableStateOf(false) }
    var isSigningUp by remember { mutableStateOf(false) }
    var signUpError by remember { mutableStateOf<String?>(null) }

    // Phone Auth states
    var phoneInput by remember { mutableStateOf("+91 ") }
    var otpInput by remember { mutableStateOf("") }
    var isOtpSent by remember { mutableStateOf(false) }
    var isVerifyingPhone by remember { mutableStateOf(false) }
    var phoneError by remember { mutableStateOf<String?>(null) }

    // Forgot Password Dialog
    var showForgotPasswordDialog by remember { mutableStateOf(false) }
    var resetEmailInput by remember { mutableStateOf("") }

    val passwordStrength = remember(signUpPassword) {
        when {
            signUpPassword.isEmpty() -> 0
            signUpPassword.length < 6 -> 1
            signUpPassword.length < 10 && signUpPassword.any { it.isDigit() } -> 2
            signUpPassword.any { it.isDigit() } && signUpPassword.any { !it.isLetterOrDigit() } -> 3
            else -> 2
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBg0)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar with Skip/Explore option
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = CyberBg2,
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(CyberPrimary, CyberSecondary)))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(CyberSuccess)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "FIREBASE AUTH ACTIVE",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                            color = CyberPrimary
                        )
                    }
                }

                TextButton(
                    onClick = onContinueToApp,
                    modifier = Modifier.testTag("skip_auth_button")
                ) {
                    Text(
                        text = "Explore as Guest",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = CyberTextSecondary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Skip",
                        tint = CyberTextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Cyber Logo & Brand Header
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(CyberPrimary, CyberSecondary)
                        )
                    )
                    .border(2.dp, CyberPrimary, RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "CyberHub Logo",
                    tint = CyberBg0,
                    modifier = Modifier.size(40.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "CYBERHUB",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.sp
                ),
                color = CyberTextPrimary
            )

            Text(
                text = "Sign in to access courses, tools & unlock Admin privileges",
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Auth Tabs: Sign In / Sign Up / Google & Phone / Guest
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = CyberBg1,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberLine1, RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    AuthTabButton(
                        text = "Sign In",
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0; signInError = null },
                        modifier = Modifier.weight(1f)
                    )
                    AuthTabButton(
                        text = "Sign Up",
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1; signUpError = null },
                        modifier = Modifier.weight(1f)
                    )
                    AuthTabButton(
                        text = "Google/Phone",
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        modifier = Modifier.weight(1.2f)
                    )
                    AuthTabButton(
                        text = "Guest",
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        modifier = Modifier.weight(0.9f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // TAB 0: SIGN IN
            if (selectedTab == 0) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberBg1),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        Text(
                            text = "Sign In with Email",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = CyberTextPrimary
                        )
                        Text(
                            text = "Use your registered email or admin credentials",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = signInEmail,
                            onValueChange = { signInEmail = it; signInError = null },
                            label = { Text("Email Address") },
                            placeholder = { Text("you@example.com") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = CyberPrimary) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("signin_email_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = CyberTextPrimary,
                                unfocusedTextColor = CyberTextPrimary,
                                focusedBorderColor = CyberPrimary,
                                unfocusedBorderColor = CyberLine1
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = signInPassword,
                            onValueChange = { signInPassword = it; signInError = null },
                            label = { Text("Password") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = CyberPrimary) },
                            trailingIcon = {
                                IconButton(onClick = { isSignInPasswordVisible = !isSignInPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isSignInPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Toggle password visibility",
                                        tint = CyberTextSecondary
                                    )
                                }
                            },
                            visualTransformation = if (isSignInPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("signin_password_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = CyberTextPrimary,
                                unfocusedTextColor = CyberTextPrimary,
                                focusedBorderColor = CyberPrimary,
                                unfocusedBorderColor = CyberLine1
                            )
                        )

                        // Forgot Password Link
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = {
                                    resetEmailInput = signInEmail
                                    showForgotPasswordDialog = true
                                }
                            ) {
                                Text("Forgot Password?", color = CyberPrimary, fontSize = 12.sp)
                            }
                        }

                        if (signInError != null) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = CyberDanger.copy(alpha = 0.15f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = CyberDanger, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(signInError ?: "", color = CyberDanger, fontSize = 12.sp)
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        Button(
                            onClick = {
                                isSigningIn = true
                                signInError = null
                                viewModel.signInWithEmail(signInEmail, signInPassword) { success, err ->
                                    isSigningIn = false
                                    if (success) {
                                        Toast.makeText(context, "Signed in successfully!", Toast.LENGTH_SHORT).show()
                                        onContinueToApp()
                                    } else {
                                        signInError = err ?: "Failed to sign in. Please check credentials."
                                    }
                                }
                            },
                            enabled = !isSigningIn && signInEmail.isNotBlank() && signInPassword.isNotBlank(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBg0),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("submit_signin_button")
                        ) {
                            if (isSigningIn) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = CyberBg0)
                            } else {
                                Icon(Icons.Default.Login, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Sign In", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text("Don't have an account? ", color = CyberTextSecondary, fontSize = 12.sp)
                            Text(
                                text = "Create Account",
                                color = CyberPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.clickable { selectedTab = 1 }
                            )
                        }
                    }
                }
            }

            // TAB 1: SIGN UP
            if (selectedTab == 1) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberBg1),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        Text(
                            text = "Create CyberHub Account",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = CyberTextPrimary
                        )
                        Text(
                            text = "Registers your UID automatically in Firebase Auth & Firestore",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = signUpName,
                            onValueChange = { signUpName = it },
                            label = { Text("Full Name / Handle") },
                            placeholder = { Text("Abhiraj / CyberSec") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = CyberPrimary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = CyberTextPrimary,
                                unfocusedTextColor = CyberTextPrimary,
                                focusedBorderColor = CyberPrimary,
                                unfocusedBorderColor = CyberLine1
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = signUpEmail,
                            onValueChange = { signUpEmail = it; signUpError = null },
                            label = { Text("Email Address") },
                            placeholder = { Text("you@cyberhub.app") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = CyberPrimary) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("signup_email_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = CyberTextPrimary,
                                unfocusedTextColor = CyberTextPrimary,
                                focusedBorderColor = CyberPrimary,
                                unfocusedBorderColor = CyberLine1
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = signUpPassword,
                            onValueChange = { signUpPassword = it; signUpError = null },
                            label = { Text("Password (min 6 characters)") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = CyberPrimary) },
                            trailingIcon = {
                                IconButton(onClick = { isSignUpPasswordVisible = !isSignUpPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isSignUpPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Toggle visibility",
                                        tint = CyberTextSecondary
                                    )
                                }
                            },
                            visualTransformation = if (isSignUpPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("signup_password_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = CyberTextPrimary,
                                unfocusedTextColor = CyberTextPrimary,
                                focusedBorderColor = CyberPrimary,
                                unfocusedBorderColor = CyberLine1
                            )
                        )

                        // Password Strength Bar
                        if (signUpPassword.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val strengthColor = when (passwordStrength) {
                                    1 -> CyberDanger
                                    2 -> CyberWarning
                                    else -> CyberSuccess
                                }
                                val strengthText = when (passwordStrength) {
                                    1 -> "Weak"
                                    2 -> "Medium"
                                    else -> "Strong"
                                }
                                LinearProgressIndicator(
                                    progress = { (passwordStrength / 3f) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    color = strengthColor,
                                    trackColor = CyberBg2
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(strengthText, color = strengthColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = signUpConfirmPassword,
                            onValueChange = { signUpConfirmPassword = it; signUpError = null },
                            label = { Text("Confirm Password") },
                            leadingIcon = { Icon(Icons.Default.LockClock, contentDescription = null, tint = CyberPrimary) },
                            visualTransformation = if (isSignUpPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = CyberTextPrimary,
                                unfocusedTextColor = CyberTextPrimary,
                                focusedBorderColor = CyberPrimary,
                                unfocusedBorderColor = CyberLine1
                            )
                        )

                        if (signUpError != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = CyberDanger.copy(alpha = 0.15f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = CyberDanger, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(signUpError ?: "", color = CyberDanger, fontSize = 12.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (signUpPassword != signUpConfirmPassword) {
                                    signUpError = "Passwords do not match"
                                    return@Button
                                }
                                isSigningUp = true
                                signUpError = null
                                viewModel.signUpWithDetails(signUpName, signUpEmail, signUpPassword) { success, err ->
                                    isSigningUp = false
                                    if (success) {
                                        Toast.makeText(context, "Account created successfully!", Toast.LENGTH_SHORT).show()
                                        onContinueToApp()
                                    } else {
                                        signUpError = err ?: "Failed to create account"
                                    }
                                }
                            },
                            enabled = !isSigningUp && signUpEmail.isNotBlank() && signUpPassword.length >= 6,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBg0),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("submit_signup_button")
                        ) {
                            if (isSigningUp) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = CyberBg0)
                            } else {
                                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Create Account", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text("Already have an account? ", color = CyberTextSecondary, fontSize = 12.sp)
                            Text(
                                text = "Sign In",
                                color = CyberPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.clickable { selectedTab = 0 }
                            )
                        }
                    }
                }
            }

            // TAB 2: GOOGLE & PHONE AUTH
            if (selectedTab == 2) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberBg1),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        Text(
                            text = "Additional Sign-In Methods",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = CyberTextPrimary
                        )
                        Text(
                            text = "Connect securely with Google or Mobile Number OTP",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        // Google Sign In Option
                        OutlinedButton(
                            onClick = {
                                viewModel.signInWithGoogleQuick("Google User", "google.user@cyberhub.app") { success, err ->
                                    if (success) {
                                        Toast.makeText(context, "Google Sign-In successful!", Toast.LENGTH_SHORT).show()
                                        onContinueToApp()
                                    } else {
                                        Toast.makeText(context, err ?: "Google sign-in failed", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(CyberPrimary, CyberSecondary))),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("google_signin_button")
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "G",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 14.sp,
                                        color = Color(0xFF4285F4)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Continue with Google",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = CyberTextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        HorizontalDivider(color = CyberLine1)

                        Spacer(modifier = Modifier.height(16.dp))

                        // Phone Number Login Section
                        Text(
                            text = "Sign in via Mobile Number (OTP)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = CyberTextPrimary
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = phoneInput,
                            onValueChange = { phoneInput = it; phoneError = null },
                            label = { Text("Mobile Number") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = CyberPrimary) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = CyberTextPrimary,
                                unfocusedTextColor = CyberTextPrimary,
                                focusedBorderColor = CyberPrimary,
                                unfocusedBorderColor = CyberLine1
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        if (!isOtpSent) {
                            Button(
                                onClick = {
                                    if (phoneInput.trim().length >= 10) {
                                        isOtpSent = true
                                        Toast.makeText(context, "OTP code 123456 sent to $phoneInput", Toast.LENGTH_LONG).show()
                                    } else {
                                        phoneError = "Please enter a valid 10-digit mobile number"
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CyberSecondary, contentColor = Color.White),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Sms, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Request OTP Code", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            OutlinedTextField(
                                value = otpInput,
                                onValueChange = { otpInput = it; phoneError = null },
                                label = { Text("Enter 6-digit OTP Code") },
                                placeholder = { Text("e.g. 123456") },
                                leadingIcon = { Icon(Icons.Default.Pin, contentDescription = null, tint = CyberPrimary) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = CyberTextPrimary,
                                    unfocusedTextColor = CyberTextPrimary,
                                    focusedBorderColor = CyberPrimary,
                                    unfocusedBorderColor = CyberLine1
                                )
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    isVerifyingPhone = true
                                    viewModel.signInWithPhoneSimulated(phoneInput, otpInput) { success, err ->
                                        isVerifyingPhone = false
                                        if (success) {
                                            Toast.makeText(context, "Phone Verified & Authenticated!", Toast.LENGTH_SHORT).show()
                                            onContinueToApp()
                                        } else {
                                            phoneError = err ?: "Verification failed"
                                        }
                                    }
                                },
                                enabled = !isVerifyingPhone && otpInput.isNotBlank(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBg0),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (isVerifyingPhone) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = CyberBg0, strokeWidth = 2.dp)
                                } else {
                                    Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Verify & Enter Hub", fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        if (phoneError != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(phoneError ?: "", color = CyberDanger, fontSize = 12.sp)
                        }
                    }
                }
            }

            // TAB 3: GUEST ACCESS
            if (selectedTab == 3) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberBg1),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberLine1, RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = CyberPrimary.copy(alpha = 0.15f),
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.RocketLaunch, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(28.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Instant Guest Access",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = CyberTextPrimary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Explore the full resource catalog, download tools, read daily tips, and converse with CyberBot Pro anonymously without an email. You can upgrade to a permanent account anytime from your profile.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = {
                                viewModel.signInAnonymously { success, err ->
                                    if (success) {
                                        Toast.makeText(context, "Logged in as Anonymous Guest!", Toast.LENGTH_SHORT).show()
                                        onContinueToApp()
                                    } else {
                                        Toast.makeText(context, err ?: "Guest login failed", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBg0),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("guest_login_button")
                        ) {
                            Icon(Icons.Default.Bolt, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Enter as Guest", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Admin Role Activation Guide Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberBg1),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberPrimary.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = CyberPrimary.copy(alpha = 0.15f),
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(18.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Admin Role Setup Workflow",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = CyberPrimary
                            )
                            Text(
                                text = "How to unlock the Admin Control Center in Firebase",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberTextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    AdminGuideStep(step = "1", title = "Sign Up or Sign In Above", desc = "Register using your real email so Firebase Auth assigns your unique user UID.")
                    AdminGuideStep(step = "2", title = "Document Created in Firestore", desc = "CyberHub automatically creates a document in 'users/{your_uid}' with isAdmin = false.")
                    AdminGuideStep(step = "3", title = "Change Role in Firebase Console", desc = "Open Firebase Console -> Firestore Database -> 'users' -> [your UID] and set isAdmin = true.")
                    AdminGuideStep(step = "4", title = "Dynamic Unlock", desc = "When you re-open the app or tap 'Check Role', the Admin Control Center tab unlocks automatically!")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Forgot Password Dialog
        if (showForgotPasswordDialog) {
            AlertDialog(
                onDismissRequest = { showForgotPasswordDialog = false },
                title = {
                    Text("Reset Password", fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                },
                text = {
                    Column {
                        Text(
                            "Enter your registered email address and we'll send you a password reset link via Firebase Auth.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = resetEmailInput,
                            onValueChange = { resetEmailInput = it },
                            label = { Text("Email Address") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.sendPasswordReset(resetEmailInput) { success, err ->
                                if (success) {
                                    Toast.makeText(context, "Password reset email sent!", Toast.LENGTH_LONG).show()
                                    showForgotPasswordDialog = false
                                } else {
                                    Toast.makeText(context, err ?: "Failed to send reset email", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberBg0)
                    ) {
                        Text("Send Reset Link", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showForgotPasswordDialog = false }) {
                        Text("Cancel", color = CyberTextSecondary)
                    }
                },
                containerColor = CyberBg1,
                shape = RoundedCornerShape(16.dp)
            )
        }
    }
}

@Composable
private fun AuthTabButton(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor by animateColorAsState(if (selected) CyberPrimary else Color.Transparent, label = "tabBg")
    val textColor by animateColorAsState(if (selected) CyberBg0 else CyberTextSecondary, label = "tabText")

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp),
            color = textColor,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun AdminGuideStep(
    step: String,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            shape = CircleShape,
            color = CyberBg2,
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(CyberPrimary, CyberSecondary))),
            modifier = Modifier.size(20.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(step, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CyberPrimary)
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(title, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberTextPrimary)
            Text(desc, style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp), color = CyberTextSecondary)
        }
    }
}
