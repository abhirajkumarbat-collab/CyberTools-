package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CyberHub Theme Color Palette
val CyberBg0 = Color(0xFF05070D)
val CyberBg1 = Color(0xFF0A0E17)
val CyberBg2 = Color(0xFF0F1421)
val CyberBg3 = Color(0xFF141A2B)
val CyberBg4 = Color(0xFF1A2136)

val CyberPrimary = Color(0xFF00D4FF)       // Electric Cyan
val CyberSecondary = Color(0xFFA855F7)     // Neon Purple
val CyberTertiary = Color(0xFF10B981)      // Emerald Green
val CyberSuccess = Color(0xFF10B981)       // Emerald Green
val CyberWarning = Color(0xFFF59E0B)       // Amber
val CyberDanger = Color(0xFFEF4444)        // Crimson Red

val CyberTextPrimary = Color(0xFFE8ECF3)   // Bright Off-white
val CyberTextSecondary = Color(0xFF8B98B3) // Muted Gray-Blue
val CyberTextTertiary = Color(0xFF566180)  // Deep Muted Slate

val CyberLine1 = Color(0xFF1A2135)
val CyberLine2 = Color(0xFF232B42)
val CyberLine3 = Color(0xFF2E3752)
