package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.CyberBotManager
import com.example.data.CyberDatabase
import com.example.data.CyberHubRepository
import com.example.data.FirebaseManager
import com.google.firebase.auth.FirebaseUser
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class CyberHubUiState(
    val searchQuery: String = "",
    val selectedCategory: ResourceCategory = ResourceCategory.ALL,
    val allResources: List<CyberResource> = emptyList(),
    val filteredResources: List<CyberResource> = emptyList(),
    val favoriteResources: List<CyberResource> = emptyList(),
    val selectedResourceForDetails: CyberResource? = null,
    val isAddDialogOpen: Boolean = false,
    val isLoading: Boolean = false,
    val isAiThinking: Boolean = false,
    val chatMessages: List<ChatMessage> = listOf(
        ChatMessage(
            role = "assistant",
            content = "🛡️ **Welcome to CyberBot Pro!**\nI am your cybersecurity learning assistant and tool navigator. Ask me about networking, packet inspection, ethical lab testing, or resources in your catalog."
        )
    ),
    val currentNavTab: Int = 0, // 0 = Home, 1 = Catalog, 2 = CyberBot, 3 = Saved, 4 = Admin
    val syncStatus: String = "Firebase Active",
    val isGeminiConfigured: Boolean = false,
    val isAdmin: Boolean = false,
    val currentUserEmail: String? = null,
    val currentUserId: String? = null,
    val isAuthDialogOpen: Boolean = false,
    val isCheckingAdminRole: Boolean = false,
    val isAuthenticated: Boolean = false,
    val isUserGuest: Boolean = false,
    val showAuthScreen: Boolean = false,
    val publishQueue: List<QueueItem> = emptyList(),
    val activityLogs: List<ActivityLogItem> = listOf(
        ActivityLogItem(action = "System Initialized", detail = "CyberHub v9 Admin Core Active", icon = "🛡️")
    ),
    val adminNotifications: List<AdminNotification> = emptyList(),
    val mediaLibrary: List<AdminMediaItem> = emptyList(),
    val appConfig: AdminAppConfig = AdminAppConfig(),
    val featureFlags: Map<String, Boolean> = mapOf(
        "ai_assistant" to true,
        "apk_gallery" to true,
        "folders" to true,
        "files_section" to true,
        "long_videos" to true,
        "short_videos" to true,
        "bundles_section" to true,
        "messages_section" to true,
        "daily_highlights" to true,
        "promotions" to false,
        "offline_mode" to true,
        "dark_mode_default" to true
    ),
    val autoPublishEnabled: Boolean = true,
    val itemsPerDay: Int = 3,
    val totalAutoPublished: Int = 0
)

class CyberHubViewModel(application: Application) : AndroidViewModel(application) {
    private val database = CyberDatabase.getInstance(application)
    private val repository = CyberHubRepository(database.resourceDao())
    private val aiManager = CyberBotManager()
    val firebaseManager = FirebaseManager()

    private val _uiState = MutableStateFlow(CyberHubUiState(isGeminiConfigured = aiManager.getApiKey().isNotBlank()))
    val uiState: StateFlow<CyberHubUiState> = _uiState.asStateFlow()

    init {
        observeResources()
        observeFavorites()
        checkUserRole()
    }

    private fun observeResources() {
        viewModelScope.launch {
            repository.getAllResources().collect { resources ->
                _uiState.update { state ->
                    val filtered = filterList(resources, state.selectedCategory, state.searchQuery)
                    state.copy(
                        allResources = resources,
                        filteredResources = filtered
                    )
                }
            }
        }
    }

    private fun observeFavorites() {
        viewModelScope.launch {
            repository.getFavorites().collect { favorites ->
                _uiState.update { it.copy(favoriteResources = favorites) }
            }
        }
    }

    private fun filterList(
        list: List<CyberResource>,
        category: ResourceCategory,
        query: String
    ): List<CyberResource> {
        return list.filter { item ->
            val matchesCategory = category == ResourceCategory.ALL || item.category.equals(category.id, ignoreCase = true)
            val matchesQuery = query.isBlank() ||
                    item.title.contains(query, ignoreCase = true) ||
                    item.description.contains(query, ignoreCase = true) ||
                    item.tags.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }

    fun onSearchQueryChange(newQuery: String) {
        _uiState.update { state ->
            val filtered = filterList(state.allResources, state.selectedCategory, newQuery)
            state.copy(searchQuery = newQuery, filteredResources = filtered)
        }
    }

    fun onCategorySelect(category: ResourceCategory) {
        _uiState.update { state ->
            val filtered = filterList(state.allResources, category, state.searchQuery)
            state.copy(selectedCategory = category, filteredResources = filtered)
        }
    }

    fun selectNavTab(tabIndex: Int) {
        _uiState.update { it.copy(currentNavTab = tabIndex) }
    }

    fun openResourceDetails(resource: CyberResource) {
        _uiState.update { it.copy(selectedResourceForDetails = resource) }
    }

    fun closeResourceDetails() {
        _uiState.update { it.copy(selectedResourceForDetails = null) }
    }

    fun openAddDialog() {
        _uiState.update { it.copy(isAddDialogOpen = true) }
    }

    fun closeAddDialog() {
        _uiState.update { it.copy(isAddDialogOpen = false) }
    }

    fun toggleFavorite(resource: CyberResource) {
        viewModelScope.launch {
            val newFavStatus = !resource.isFavorite
            repository.toggleFavorite(resource.id, newFavStatus)
            if (_uiState.value.selectedResourceForDetails?.id == resource.id) {
                _uiState.update {
                    it.copy(selectedResourceForDetails = resource.copy(isFavorite = newFavStatus))
                }
            }
        }
    }

    fun addResource(
        title: String,
        description: String,
        category: ResourceCategory,
        url: String,
        version: String = "1.0",
        level: String = "Beginner",
        videoUrl: String = "",
        tags: String = ""
    ) {
        viewModelScope.launch {
            val newResource = CyberResource(
                id = UUID.randomUUID().toString(),
                title = title.trim(),
                description = description.trim(),
                category = category.id,
                url = url.trim(),
                version = version.ifBlank { "1.0" },
                level = level,
                videoUrl = videoUrl.trim(),
                tags = tags.trim(),
                timestamp = System.currentTimeMillis()
            )
            repository.addResource(newResource)
            closeAddDialog()
        }
    }

    fun deleteResource(id: String) {
        viewModelScope.launch {
            repository.deleteResource(id)
            if (_uiState.value.selectedResourceForDetails?.id == id) {
                closeResourceDetails()
            }
        }
    }

    fun bulkImportLinks(rawText: String, defaultCategory: ResourceCategory) {
        viewModelScope.launch {
            val lines = rawText.split("\n")
                .map { it.trim() }
                .filter { it.isNotBlank() && (it.startsWith("http://") || it.startsWith("https://") || it.contains(".")) }

            lines.forEach { url ->
                val detectedTitle = detectTitleFromUrl(url)
                val item = CyberResource(
                    id = UUID.randomUUID().toString(),
                    title = detectedTitle,
                    description = "Imported resource from $url. Verified for educational cybersecurity reference.",
                    category = defaultCategory.id,
                    url = url,
                    timestamp = System.currentTimeMillis()
                )
                repository.addResource(item)
            }
        }
    }

    private fun detectTitleFromUrl(url: String): String {
        return try {
            val clean = url.substringAfterLast("/").substringBefore("?").replace("-", " ").replace("_", " ")
            if (clean.isNotBlank() && clean.length > 3) clean.capitalizeWords() else "Resource (${url.take(30)}...)"
        } catch (e: Exception) {
            "Cyber Resource Link"
        }
    }

    private fun String.capitalizeWords(): String {
        return split(" ").joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }
    }

    fun sendChatMessage(query: String) {
        val trimmed = query.trim()
        if (trimmed.isBlank()) return

        val userMessage = ChatMessage(
            role = "user",
            content = trimmed
        )

        _uiState.update { state ->
            state.copy(
                chatMessages = state.chatMessages + userMessage,
                isAiThinking = true
            )
        }

        viewModelScope.launch {
            val currentScreenName = when (_uiState.value.currentNavTab) {
                0 -> "Home Dashboard"
                1 -> "Resource Catalog (${_uiState.value.selectedCategory.displayName})"
                3 -> "Saved Bookmarks"
                4 -> "Admin Control Center"
                else -> "CyberBot Assistant"
            }

            val response = aiManager.generateResponse(
                userQuery = trimmed,
                currentScreen = currentScreenName,
                availableResources = _uiState.value.allResources,
                chatHistory = _uiState.value.chatMessages
            )

            _uiState.update { state ->
                state.copy(
                    chatMessages = state.chatMessages + response,
                    isAiThinking = false
                )
            }
        }
    }

    fun clearLocalData() {
        viewModelScope.launch {
            repository.clearLocalData()
        }
    }

    fun checkUserRole() {
        _uiState.update { it.copy(isCheckingAdminRole = true) }
        val user: FirebaseUser? = firebaseManager.getCurrentUser()
        if (user != null) {
            val isGuest = user.isAnonymous
            val displayEmail = if (isGuest) "Guest (${user.uid.take(6)})" else (user.email ?: "CyberHub User")
            _uiState.update {
                it.copy(
                    isAuthenticated = true,
                    isUserGuest = isGuest,
                    currentUserEmail = displayEmail,
                    currentUserId = user.uid,
                    showAuthScreen = false
                )
            }
            firebaseManager.checkUserRole { isAdminResult: Boolean ->
                _uiState.update {
                    it.copy(
                        isAdmin = isAdminResult,
                        isCheckingAdminRole = false
                    )
                }
            }
        } else {
            _uiState.update {
                it.copy(
                    isAuthenticated = false,
                    isUserGuest = false,
                    isAdmin = false,
                    currentUserEmail = null,
                    currentUserId = null,
                    isCheckingAdminRole = false,
                    showAuthScreen = true
                )
            }
        }
    }

    fun openAuthScreen() {
        _uiState.update { it.copy(showAuthScreen = true) }
    }

    fun dismissAuthScreen() {
        // Allows skipping or closing auth screen
        _uiState.update { it.copy(showAuthScreen = false) }
    }

    fun openAuthDialog() {
        _uiState.update { it.copy(isAuthDialogOpen = true) }
    }

    fun closeAuthDialog() {
        _uiState.update { it.copy(isAuthDialogOpen = false) }
    }

    fun signInWithEmail(email: String, pass: String, onComplete: (Boolean, String?) -> Unit) {
        if (email.isBlank() || pass.isBlank()) {
            onComplete(false, "Email and password cannot be empty")
            return
        }
        firebaseManager.auth.signInWithEmailAndPassword(email.trim(), pass)
            .addOnSuccessListener {
                checkUserRole()
                onComplete(true, null)
            }
            .addOnFailureListener { exception: Exception ->
                onComplete(false, exception.message)
            }
    }

    fun signUpWithEmail(email: String, pass: String, onComplete: (Boolean, String?) -> Unit) {
        signUpWithDetails(name = "", email = email, pass = pass, onComplete = onComplete)
    }

    fun signUpWithDetails(name: String, email: String, pass: String, onComplete: (Boolean, String?) -> Unit) {
        if (email.isBlank() || pass.length < 6) {
            onComplete(false, "Password must be at least 6 characters")
            return
        }
        firebaseManager.auth.createUserWithEmailAndPassword(email.trim(), pass)
            .addOnSuccessListener { authResult ->
                val uid = authResult.user?.uid
                if (uid != null) {
                    val userData = mutableMapOf<String, Any>(
                        "email" to email.trim(),
                        "name" to name.trim(),
                        "isAdmin" to false,
                        "createdAt" to System.currentTimeMillis()
                    )
                    firebaseManager.firestore.collection("users").document(uid)
                        .set(userData, com.google.firebase.firestore.SetOptions.merge())
                }
                checkUserRole()
                onComplete(true, null)
            }
            .addOnFailureListener { exception: Exception ->
                onComplete(false, exception.message)
            }
    }

    fun sendPasswordReset(email: String, onComplete: (Boolean, String?) -> Unit) {
        firebaseManager.sendPasswordReset(email, onComplete)
    }

    fun signInWithGoogleQuick(name: String, email: String, onComplete: (Boolean, String?) -> Unit) {
        // Authenticates with Firebase and saves Google Profile in Firestore
        firebaseManager.auth.signInAnonymously()
            .addOnSuccessListener { authResult ->
                val uid = authResult.user?.uid
                if (uid != null) {
                    val userData = mapOf(
                        "name" to name.ifBlank { "Google User" },
                        "email" to email.ifBlank { "google.user@cyberhub.app" },
                        "provider" to "google.com",
                        "isAdmin" to false,
                        "createdAt" to System.currentTimeMillis()
                    )
                    firebaseManager.firestore.collection("users").document(uid)
                        .set(userData, com.google.firebase.firestore.SetOptions.merge())
                }
                checkUserRole()
                onComplete(true, null)
            }
            .addOnFailureListener { exception ->
                onComplete(false, exception.message)
            }
    }

    fun signInWithPhoneSimulated(phone: String, otp: String, onComplete: (Boolean, String?) -> Unit) {
        if (phone.isBlank() || otp.length < 4) {
            onComplete(false, "Please enter a valid phone number and OTP code")
            return
        }
        firebaseManager.auth.signInAnonymously()
            .addOnSuccessListener { authResult ->
                val uid = authResult.user?.uid
                if (uid != null) {
                    val userData = mapOf(
                        "phone" to phone.trim(),
                        "provider" to "phone",
                        "isAdmin" to false,
                        "createdAt" to System.currentTimeMillis()
                    )
                    firebaseManager.firestore.collection("users").document(uid)
                        .set(userData, com.google.firebase.firestore.SetOptions.merge())
                }
                checkUserRole()
                onComplete(true, null)
            }
            .addOnFailureListener { exception ->
                onComplete(false, exception.message)
            }
    }

    fun signInAnonymously(onComplete: (Boolean, String?) -> Unit) {
        firebaseManager.auth.signInAnonymously()
            .addOnSuccessListener {
                checkUserRole()
                onComplete(true, null)
            }
            .addOnFailureListener { exception: Exception ->
                onComplete(false, exception.message)
            }
    }

    fun signOut() {
        firebaseManager.auth.signOut()
        checkUserRole()
    }

    fun addBulkToQueue(items: List<QueueItem>) {
        _uiState.update { state ->
            val updated = state.publishQueue + items
            state.copy(publishQueue = updated)
        }
        logAdminActivity("Bulk Added to Queue", "${items.size} items scheduled", "📅")
    }

    fun updateQueueItemDate(id: String, date: String) {
        _uiState.update { state ->
            val updated = state.publishQueue.map {
                if (it.id == id) it.copy(scheduledDate = date) else it
            }
            state.copy(publishQueue = updated)
        }
        logAdminActivity("Updated Schedule", "Item $id -> $date", "📅")
    }

    fun publishQueueItem(item: QueueItem) {
        viewModelScope.launch {
            val res = CyberResource(
                id = item.id,
                title = item.title,
                description = item.description,
                category = item.collection,
                url = item.url,
                tags = item.tags.joinToString(","),
                status = "published",
                copyright = item.copyright
            )
            repository.insertResource(res)
            _uiState.update { state ->
                val updatedQueue = state.publishQueue.map {
                    if (it.id == item.id) it.copy(status = "published", publishedAt = System.currentTimeMillis()) else it
                }
                state.copy(
                    publishQueue = updatedQueue,
                    totalAutoPublished = state.totalAutoPublished + 1
                )
            }
            logAdminActivity("Published Queue Item", item.title, "🚀")
        }
    }

    fun publishDueNow() {
        val today = AdminDateUtils.getTodayString()
        val dueItems = _uiState.value.publishQueue.filter { it.status == "pending" && it.scheduledDate.isNotBlank() && it.scheduledDate <= today }
        if (dueItems.isEmpty()) return
        viewModelScope.launch {
            dueItems.forEach { item ->
                val res = CyberResource(
                    id = item.id,
                    title = item.title,
                    description = item.description,
                    category = item.collection,
                    url = item.url,
                    tags = item.tags.joinToString(","),
                    status = "published",
                    copyright = item.copyright
                )
                repository.insertResource(res)
            }
            _uiState.update { state ->
                val dueIds = dueItems.map { it.id }.toSet()
                val updatedQueue = state.publishQueue.map {
                    if (it.id in dueIds) it.copy(status = "published", publishedAt = System.currentTimeMillis()) else it
                }
                state.copy(
                    publishQueue = updatedQueue,
                    totalAutoPublished = state.totalAutoPublished + dueItems.size
                )
            }
            logAdminActivity("Published Due Items", "${dueItems.size} items published", "🚀")
        }
    }

    fun autoScheduleQueue() {
        val unscheduled = _uiState.value.publishQueue.filter { it.status == "pending" && it.scheduledDate.isBlank() }
        if (unscheduled.isEmpty()) return
        val perDay = _uiState.value.itemsPerDay.coerceAtLeast(1)
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_YEAR, 1)

        val updatedMap = mutableMapOf<String, String>()
        var countInDay = 0
        unscheduled.forEach { item ->
            if (countInDay >= perDay) {
                cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
                countInDay = 0
            }
            updatedMap[item.id] = sdf.format(cal.time)
            countInDay++
        }

        _uiState.update { state ->
            val updatedQueue = state.publishQueue.map { item ->
                val date = updatedMap[item.id]
                if (date != null) item.copy(scheduledDate = date) else item
            }
            state.copy(publishQueue = updatedQueue)
        }
        logAdminActivity("Auto-Scheduled Queue", "${unscheduled.size} items distributed ($perDay/day)", "📅")
    }

    fun deleteQueueItem(id: String) {
        _uiState.update { state ->
            state.copy(publishQueue = state.publishQueue.filter { it.id != id })
        }
        logAdminActivity("Deleted Queue Item", id, "🗑️")
    }

    fun clearQueue() {
        _uiState.update { state -> state.copy(publishQueue = emptyList()) }
        logAdminActivity("Cleared Queue", "All items removed", "🗑️")
    }

    fun toggleAutoPublish(enabled: Boolean) {
        _uiState.update { it.copy(autoPublishEnabled = enabled) }
        logAdminActivity("Auto-Publish Toggled", if (enabled) "Enabled" else "Disabled", "⚙️")
    }

    fun updateItemsPerDay(count: Int) {
        _uiState.update { it.copy(itemsPerDay = count.coerceIn(1, 20)) }
    }

    fun toggleFeatureFlag(key: String, enabled: Boolean) {
        _uiState.update { state ->
            val updated = state.featureFlags.toMutableMap()
            updated[key] = enabled
            state.copy(featureFlags = updated)
        }
        logAdminActivity("Toggled Feature Flag", "$key = $enabled", "🚩")
    }

    fun sendAdminNotification(title: String, body: String, deepLink: String, audience: String, image: String) {
        val notif = AdminNotification(
            title = title,
            body = body,
            deepLink = deepLink,
            audience = audience,
            image = image
        )
        _uiState.update { state ->
            state.copy(adminNotifications = listOf(notif) + state.adminNotifications)
        }
        firebaseManager.firestore.collection("notifications").document(notif.id)
            .set(mapOf(
                "id" to notif.id,
                "title" to notif.title,
                "body" to notif.body,
                "deepLink" to notif.deepLink,
                "audience" to notif.audience,
                "image" to notif.image,
                "timestamp" to notif.timestamp
            ), com.google.firebase.firestore.SetOptions.merge())
        logAdminActivity("Sent Notification", title, "🔔")
    }

    fun deleteNotification(id: String) {
        _uiState.update { state ->
            state.copy(adminNotifications = state.adminNotifications.filter { it.id != id })
        }
    }

    fun saveAppConfig(config: AdminAppConfig) {
        _uiState.update { it.copy(appConfig = config) }
        firebaseManager.firestore.collection("app_config").document("global")
            .set(mapOf(
                "appName" to config.appName,
                "tagline" to config.tagline,
                "welcomeMessage" to config.welcomeMessage,
                "maintenanceMode" to config.maintenanceMode,
                "forceUpdate" to config.forceUpdate,
                "minAppVersion" to config.minAppVersion,
                "latestAppVersion" to config.latestAppVersion,
                "updateMessage" to config.updateMessage
            ), com.google.firebase.firestore.SetOptions.merge())
        logAdminActivity("Updated App Config", config.appName, "⚙️")
    }

    fun addMediaItem(name: String, url: String, type: String) {
        val item = AdminMediaItem(name = name, url = url, type = type)
        _uiState.update { state ->
            state.copy(mediaLibrary = listOf(item) + state.mediaLibrary)
        }
        logAdminActivity("Added Media", name, "🖼️")
    }

    fun deleteMediaItem(id: String) {
        _uiState.update { state ->
            state.copy(mediaLibrary = state.mediaLibrary.filter { it.id != id })
        }
    }

    fun logAdminActivity(action: String, detail: String, icon: String) {
        val log = ActivityLogItem(action = action, detail = detail, icon = icon)
        _uiState.update { state ->
            state.copy(activityLogs = (listOf(log) + state.activityLogs).take(100))
        }
    }

    fun clearActivityLogs() {
        _uiState.update { it.copy(activityLogs = emptyList()) }
    }
}
