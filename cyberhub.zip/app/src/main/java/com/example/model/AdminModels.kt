package com.example.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class QueueItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val collection: String = ResourceCategory.METHODS.id,
    val url: String = "",
    val description: String = "",
    val platform: String = "Web",
    val platformIcon: String = "🌐",
    val scheduledDate: String = "", // YYYY-MM-DD
    val status: String = "pending", // "pending", "published"
    val addedAt: Long = System.currentTimeMillis(),
    val publishedAt: Long? = null,
    val tags: List<String> = emptyList(),
    val copyright: String = "© CyberHub · Educational use only"
)

data class ActivityLogItem(
    val id: String = UUID.randomUUID().toString(),
    val action: String = "",
    val detail: String = "",
    val icon: String = "📝",
    val timestamp: Long = System.currentTimeMillis()
)

data class AdminNotification(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val body: String = "",
    val deepLink: String = "cyberhub://home",
    val audience: String = "All Users",
    val image: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class AdminAppConfig(
    val appName: String = "CyberHub",
    val tagline: String = "ADMIN v9",
    val welcomeMessage: String = "Welcome to CyberHub Pro - Server-Driven Security Hub",
    val maintenanceMode: Boolean = false,
    val forceUpdate: Boolean = false,
    val minAppVersion: String = "1.0.0",
    val latestAppVersion: String = "9.0.0",
    val updateMessage: String = "A new version of CyberHub is available with upgraded security modules!"
)

data class AdminMediaItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val url: String = "",
    val type: String = "image", // "image" or "video"
    val timestamp: Long = System.currentTimeMillis()
)

object AdminDateUtils {
    fun getTodayString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    fun formatDisplayDate(timestamp: Long): String {
        val diff = System.currentTimeMillis() - timestamp
        return when {
            diff < 60_000 -> "just now"
            diff < 3_600_000 -> "${diff / 60_000}m ago"
            diff < 86_400_000 -> "${diff / 3_600_000}h ago"
            else -> {
                val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
                sdf.format(Date(timestamp))
            }
        }
    }
}
