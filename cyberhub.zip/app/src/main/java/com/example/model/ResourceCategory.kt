package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.ui.graphics.vector.ImageVector

enum class ResourceCategory(
    val id: String,
    val displayName: String,
    val emoji: String,
    val icon: ImageVector
) {
    ALL("all", "All", "🌐", Icons.Default.Layers),
    COURSES("courses", "Courses", "🎓", Icons.Default.School),
    APK_GALLERY("apks", "APK Gallery", "📱", Icons.Default.Android),
    METHODS("methods", "Methods", "🔧", Icons.Default.Code),
    TIPS("tips", "Tips & Tricks", "💡", Icons.Default.Lightbulb),
    NEWS("news", "News & Updates", "📰", Icons.Default.Article),
    BUNDLES("bundles", "Drive Bundles", "📦", Icons.Default.FolderSpecial),
    VIDEOS("videos", "Videos", "🎬", Icons.Default.VideoLibrary),
    FILES("files", "Files & Docs", "📄", Icons.Default.Folder),
    MESSAGES("messages", "Messages", "💬", Icons.Default.Message);

    companion object {
        fun fromId(id: String?): ResourceCategory {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) || it.name.equals(id, ignoreCase = true) } ?: ALL
        }
    }
}
