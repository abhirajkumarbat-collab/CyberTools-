package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "resources")
data class CyberResource(
    @PrimaryKey val id: String = "",
    val title: String = "",
    val subtitle: String = "",
    val description: String = "",
    val category: String = ResourceCategory.COURSES.id,
    val level: String = "Beginner", // Beginner, Intermediate, Advanced, All
    val duration: String = "",
    val version: String = "1.0",
    val size: String = "",
    val thumbnailUrl: String = "",
    val url: String = "", // Direct download link, external link, or drive URL
    val videoUrl: String = "", // Setup or preview video
    val tags: String = "", // Comma-separated tags
    val status: String = "published", // published, draft
    val isFavorite: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val author: String = "Admin",
    val copyright: String = "© CyberHub"
) {
    fun toFirestoreMap(): Map<String, Any> {
        return mapOf(
            "id" to id,
            "title" to title,
            "subtitle" to subtitle,
            "description" to description,
            "category" to category,
            "level" to level,
            "duration" to duration,
            "version" to version,
            "size" to size,
            "thumbnailUrl" to thumbnailUrl,
            "url" to url,
            "videoUrl" to videoUrl,
            "tags" to tags,
            "status" to status,
            "timestamp" to timestamp,
            "author" to author,
            "copyright" to copyright
        )
    }

    companion object {
        fun fromFirestoreMap(id: String, map: Map<String, Any?>): CyberResource {
            return CyberResource(
                id = id,
                title = map["title"] as? String ?: "",
                subtitle = map["subtitle"] as? String ?: "",
                description = (map["description"] ?: map["body"]) as? String ?: "",
                category = map["category"] as? String ?: ResourceCategory.COURSES.id,
                level = map["level"] as? String ?: "Beginner",
                duration = map["duration"] as? String ?: "",
                version = map["version"] as? String ?: "1.0",
                size = map["size"] as? String ?: "",
                thumbnailUrl = (map["thumbnailUrl"] ?: map["thumbnail"] ?: map["logo"]) as? String ?: "",
                url = (map["url"] ?: map["downloadUrl"] ?: map["driveUrl"] ?: map["linkUrl"]) as? String ?: "",
                videoUrl = (map["videoUrl"] ?: map["setupVideo"] ?: map["previewVideo"]) as? String ?: "",
                tags = (map["tags"] as? String) ?: (map["tags"] as? List<*>)?.joinToString(",") ?: "",
                status = map["status"] as? String ?: "published",
                isFavorite = false,
                timestamp = (map["timestamp"] as? Long) ?: (map["createdAt"] as? Long) ?: System.currentTimeMillis(),
                author = map["author"] as? String ?: map["instructor"] as? String ?: "Admin",
                copyright = map["copyright"] as? String ?: "© CyberHub"
            )
        }
    }
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: String, // "user" or "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val suggestedResourceIds: List<String> = emptyList()
)
